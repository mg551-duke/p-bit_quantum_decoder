# p-bit decoder — circuit-level noise (LER vs p) reproduction package

Self-contained snapshot of the code, inputs, and results for the **circuit-level
noise** study of the p-bit DEM decoder on the gross bivariate-bicycle code
`bb [[144,12,12]]` (`A = x^3+y+y^2`, `B = y^3+x+x^2`), `distance=12, rounds=12`,
`uniform_circuit` noise. Extracted from the `p-bit_quantum_decoder` repo on
2026-06-23. Everything here is a faithful copy — nothing in the source repo was modified.

## What "these results" are
Logical error rate (**LER**) vs physical error rate **p ∈ {0.001 … 0.005}** for two
decoding problems, both solved by the *same* p-bit solver:

- **filtered** — decode only the Z-basis detectors (`--basis-filter Z`, 936 detectors /
  8784 mechanisms). This is the same problem RelayBP benchmarks; the apples-to-apples baseline.
- **correlated** — decode the **full** detector error model (1728 detectors / 67824
  mechanisms), keeping cross-basis correlations. Lower LER, ~5–10× more expensive per shot.

Headline numbers live in `results/ler_vs_p_bb144_2026-06/` (see `FILTERED_RESULT.txt`,
`RESULT_FINAL.txt`, `summary.csv`, and that folder's own `README.md`).

## Layout
```
src/pbit_qec/                     decoder library (faithful full-package copy)
  circuit_decoder.py              THE decoder: ColoredBlockGibbsDecoder (chromatic block
                                  Gibbs over the DEM; this is what produces every result here)
  dem.py                          Stim DEM -> sparse H / priors / observables
  detector_filter.py              basis (X/Z) detector filtering for the "filtered" problem
  ... (rest of the package; imported transitively by __init__)
experiments/bench_circuit_pbit.py the simulation/benchmark harness (sampling + decode + LER)
circuits/                         the 10 Stim circuits decoded (memory_X & memory_Z, p=0.001..0.005)
results/ler_vs_p_bb144_2026-06/   results, provenance logs, plots, and all campaign scripts
  README.md                       detailed study writeup + tuning history + best configs
  FILTERED_RESULT.txt             filtered LER (tv=1..5) per p
  summary.csv / RESULT_FINAL.txt  correlated full-DEM LER per p
  scripts/                        every campaign/tuning script, incl. the p=0.001 campaign
  logs/p001/                      live logs of the in-progress p=0.001 campaign (snapshot)
pyproject.toml / uv.lock          dependencies (pinned)
```

## Environment
Python 3.11+. Core deps: `numpy`, `scipy`, `stim`. GPU runs additionally need `cupy`
(CUDA). The decoder runs on CPU (`--device cpu`) or GPU (`--device cuda`); all production
results were produced on NVIDIA A100s.

```bash
# with uv (reproduces the pinned lockfile)
uv sync                      # CPU; add the GPU extra / install cupy-cuda12x for --device cuda
# or with pip
pip install numpy scipy stim
pip install cupy-cuda12x     # only for --device cuda
```
Make the package importable, e.g. `export PYTHONPATH=src` (or `pip install -e .`).

## The decoder
`ColoredBlockGibbsDecoder` (`src/pbit_qec/circuit_decoder.py`) samples the energy
`E(e) = sum_j lambda_j e_j + rho * |H e XOR s|_1` with `lambda_j = log((1-p_j)/p_j)` via
annealed multi-chain **chromatic block Gibbs**, selecting the lowest-weight
syndrome-consistent sample. It decodes thousands of shots × chains in one batched
sweep on the GPU.

**Mid-leg compaction** (`compact=True`, `compact_interval=32`; CLI `--no-compact`,
`--compact-interval`): once a shot has collected its `target_valid` valid samples its
columns are dropped from the annealed working set, so later sweeps run at reduced width.
~1.6× faster at p=0.001 with statistically identical LER (validated by an 80k-shot CPU
A/B and the unit tests). Active only when `--capture-targets` is used.

## Reproduce
`PYTHONPATH=src` assumed; pick `--device cuda` (GPU) or `--device cpu`. The
`--capture-targets 1,2,3,4,5` flag records, in one run, the result a `target_valid=k`
run would give for each k (the `tv=k` lines).

```bash
CIRC=circuits   # bundled circuits

# FILTERED  (rho=0.20, sweeps=750) — example at p=0.003
PYTHONPATH=src python experiments/bench_circuit_pbit.py --device cuda \
  --shots 20000 --chains 128 --sweeps 750 --rho-scales 0.20 --max-legs 24 \
  --gamma 1.0 --selection min_weight --basis-filter Z --capture-targets 1,2,3,4,5 \
  --circuit "$CIRC/circuit=bicycle_bivariate_144_12_12_memory_Z,distance=12,rounds=12,error_rate=0.003,noise_model=uniform_circuit,basis=CX,A=x^3+y+y^2,B=y^3+x+x^2.stim"

# CORRELATED  (full DEM, rho=0.30, sweeps=500) — example at p=0.003
PYTHONPATH=src python experiments/bench_circuit_pbit.py --device cuda \
  --shots 20000 --chains 128 --sweeps 500 --rho-scales 0.30 --max-legs 24 \
  --gamma 1.0 --selection min_weight --capture-targets 1,2,3,4,5 \
  --circuit "$CIRC/circuit=bicycle_bivariate_144_12_12_memory_X,distance=12,rounds=12,error_rate=0.003,noise_model=uniform_circuit,basis=CX,A=x^3+y+y^2,B=y^3+x+x^2.stim"
```
Each line printed is `tv=k LER=... (errors/shots) valid=... invalid=... meanW=... ms/shot`.

### Full p-sweep / campaigns
The exact LER-vs-p campaigns (resume-safe, multi-GPU shard pools) are in
`results/ler_vs_p_bb144_2026-06/scripts/` — e.g. `filtered_campaign.sh`,
`shardcamp.sh`, and the p=0.001 driver `p001_campaign.sh` (+ `p001_pool.py` monitor).
See `results/ler_vs_p_bb144_2026-06/README.md` for tuning history and chosen configs.

## Circuits
`circuits/` holds the Stim circuit files (the standard RelayBP bb144 set) for both memory
experiments at p=0.001..0.005. Pass them with `--circuit`.
