# worker correlated_g2 start Tue Jun 23 01:50:24 PM PDT 2026 chunk=4000 base=300000000 args: --device cuda --chains 128 --sweeps 500 --max-legs 24 --rho-scales 0.30 --gamma 1.0 --selection min_weight --capture-targets 1,2,3,4,5
## shard k=0 seed=300000000 shots=4000 Tue Jun 23 01:53:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.48 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.48 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.48 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.48 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.48 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
## shard k=1 seed=300000001 shots=4000 Tue Jun 23 01:57:21 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=2 seed=300000002 shots=4000 Tue Jun 23 02:00:44 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  49.96 ms/shot (wall 200s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  49.96 ms/shot (wall 200s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  49.96 ms/shot (wall 200s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  49.96 ms/shot (wall 200s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  49.96 ms/shot (wall 200s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=3 seed=300000003 shots=4000 Tue Jun 23 02:04:17 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.28 ms/shot (wall 209s)  legs=1.00 sw_exec=276.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.28 ms/shot (wall 209s)  legs=1.00 sw_exec=276.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.28 ms/shot (wall 209s)  legs=1.00 sw_exec=276.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.28 ms/shot (wall 209s)  legs=1.00 sw_exec=276.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.28 ms/shot (wall 209s)  legs=1.00 sw_exec=276.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=4 seed=300000004 shots=4000 Tue Jun 23 02:07:43 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=5 seed=300000005 shots=4000 Tue Jun 23 02:11:09 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=6 seed=300000006 shots=4000 Tue Jun 23 02:14:44 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.84 ms/shot (wall 211s)  legs=1.00 sw_exec=275.6  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.84 ms/shot (wall 211s)  legs=1.00 sw_exec=275.6  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.84 ms/shot (wall 211s)  legs=1.00 sw_exec=275.6  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.84 ms/shot (wall 211s)  legs=1.00 sw_exec=275.6  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.84 ms/shot (wall 211s)  legs=1.00 sw_exec=275.6  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
## shard k=7 seed=300000007 shots=4000 Tue Jun 23 02:18:08 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=8 seed=300000008 shots=4000 Tue Jun 23 02:21:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.21 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.21 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.21 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.21 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.21 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=9 seed=300000009 shots=4000 Tue Jun 23 02:24:59 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.85 ms/shot (wall 203s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.85 ms/shot (wall 203s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.85 ms/shot (wall 203s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.85 ms/shot (wall 203s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.85 ms/shot (wall 203s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
## shard k=10 seed=300000010 shots=4000 Tue Jun 23 02:29:07 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  61.11 ms/shot (wall 244s)  legs=1.00 sw_exec=309.0  legs_max=6 legs_p99=1  sw_max=2884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  61.11 ms/shot (wall 244s)  legs=1.00 sw_exec=309.0  legs_max=6 legs_p99=1  sw_max=2884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  61.11 ms/shot (wall 244s)  legs=1.00 sw_exec=309.0  legs_max=6 legs_p99=1  sw_max=2884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  61.11 ms/shot (wall 244s)  legs=1.00 sw_exec=309.0  legs_max=6 legs_p99=1  sw_max=2884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  61.11 ms/shot (wall 244s)  legs=1.00 sw_exec=309.0  legs_max=6 legs_p99=1  sw_max=2884 sw_p99=500
## shard k=11 seed=300000011 shots=4000 Tue Jun 23 02:32:31 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.20 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.20 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.20 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.20 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.20 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=12 seed=300000012 shots=4000 Tue Jun 23 02:35:55 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=13 seed=300000013 shots=4000 Tue Jun 23 02:39:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
## shard k=14 seed=300000014 shots=4000 Tue Jun 23 02:42:50 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.50 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.50 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.50 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.50 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.50 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=15 seed=300000015 shots=4000 Tue Jun 23 02:46:13 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=245.4  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=245.4  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=245.4  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=245.4  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=245.4  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=16 seed=300000016 shots=4000 Tue Jun 23 02:49:43 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
## shard k=17 seed=300000017 shots=4000 Tue Jun 23 02:53:06 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  50.03 ms/shot (wall 200s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  50.03 ms/shot (wall 200s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  50.03 ms/shot (wall 200s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  50.03 ms/shot (wall 200s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  50.03 ms/shot (wall 200s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=18 seed=300000018 shots=4000 Tue Jun 23 02:56:37 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
## shard k=19 seed=300000019 shots=4000 Tue Jun 23 03:00:02 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=20 seed=300000020 shots=4000 Tue Jun 23 03:03:27 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.48 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.48 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.48 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.48 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.48 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=21 seed=300000021 shots=4000 Tue Jun 23 03:06:54 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=267.1  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=267.1  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=267.1  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=267.1  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=267.1  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
## shard k=22 seed=300000022 shots=4000 Tue Jun 23 03:11:44 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  71.74 ms/shot (wall 287s)  legs=1.00 sw_exec=296.5  legs_max=10 legs_p99=1  sw_max=4756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  71.74 ms/shot (wall 287s)  legs=1.00 sw_exec=296.5  legs_max=10 legs_p99=1  sw_max=4756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  71.74 ms/shot (wall 287s)  legs=1.00 sw_exec=296.5  legs_max=10 legs_p99=1  sw_max=4756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  71.74 ms/shot (wall 287s)  legs=1.00 sw_exec=296.5  legs_max=10 legs_p99=1  sw_max=4756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  71.74 ms/shot (wall 287s)  legs=1.00 sw_exec=296.5  legs_max=10 legs_p99=1  sw_max=4756 sw_p99=500
## shard k=23 seed=300000023 shots=4000 Tue Jun 23 03:15:09 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=24 seed=300000024 shots=4000 Tue Jun 23 03:18:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.23 ms/shot (wall 213s)  legs=1.00 sw_exec=285.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.23 ms/shot (wall 213s)  legs=1.00 sw_exec=285.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.23 ms/shot (wall 213s)  legs=1.00 sw_exec=285.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.23 ms/shot (wall 213s)  legs=1.00 sw_exec=285.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.23 ms/shot (wall 213s)  legs=1.00 sw_exec=285.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=25 seed=300000025 shots=4000 Tue Jun 23 03:22:15 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.71 ms/shot (wall 207s)  legs=1.00 sw_exec=256.6  legs_max=2 legs_p99=1  sw_max=884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.71 ms/shot (wall 207s)  legs=1.00 sw_exec=256.6  legs_max=2 legs_p99=1  sw_max=884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.71 ms/shot (wall 207s)  legs=1.00 sw_exec=256.6  legs_max=2 legs_p99=1  sw_max=884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.71 ms/shot (wall 207s)  legs=1.00 sw_exec=256.6  legs_max=2 legs_p99=1  sw_max=884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.71 ms/shot (wall 207s)  legs=1.00 sw_exec=256.6  legs_max=2 legs_p99=1  sw_max=884 sw_p99=500
## shard k=26 seed=300000026 shots=4000 Tue Jun 23 03:25:38 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.90 ms/shot (wall 200s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=27 seed=300000027 shots=4000 Tue Jun 23 03:29:02 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=28 seed=300000028 shots=4000 Tue Jun 23 03:32:29 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=266.7  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=266.7  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=266.7  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=266.7  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=266.7  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
## shard k=29 seed=300000029 shots=4000 Tue Jun 23 03:35:54 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=248.1  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=248.1  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=248.1  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=248.1  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=248.1  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=30 seed=300000030 shots=4000 Tue Jun 23 03:39:20 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=250.6  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=250.6  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=250.6  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=250.6  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=250.6  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=31 seed=300000031 shots=4000 Tue Jun 23 03:42:46 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=32 seed=300000032 shots=4000 Tue Jun 23 03:48:41 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.00 ms/shot (wall 352s)  legs=1.01 sw_exec=286.7  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.00 ms/shot (wall 352s)  legs=1.01 sw_exec=286.7  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.00 ms/shot (wall 352s)  legs=1.01 sw_exec=286.7  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.00 ms/shot (wall 352s)  legs=1.01 sw_exec=286.7  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.00 ms/shot (wall 352s)  legs=1.01 sw_exec=286.7  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=33 seed=300000033 shots=4000 Tue Jun 23 03:52:12 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.86 ms/shot (wall 207s)  legs=1.00 sw_exec=262.9  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.86 ms/shot (wall 207s)  legs=1.00 sw_exec=262.9  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.86 ms/shot (wall 207s)  legs=1.00 sw_exec=262.9  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.86 ms/shot (wall 207s)  legs=1.00 sw_exec=262.9  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.86 ms/shot (wall 207s)  legs=1.00 sw_exec=262.9  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
## shard k=34 seed=300000034 shots=4000 Tue Jun 23 03:55:50 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.74 ms/shot (wall 215s)  legs=1.00 sw_exec=270.5  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.74 ms/shot (wall 215s)  legs=1.00 sw_exec=270.5  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.74 ms/shot (wall 215s)  legs=1.00 sw_exec=270.5  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.74 ms/shot (wall 215s)  legs=1.00 sw_exec=270.5  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.74 ms/shot (wall 215s)  legs=1.00 sw_exec=270.5  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
## shard k=35 seed=300000035 shots=4000 Tue Jun 23 03:59:30 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.17 ms/shot (wall 217s)  legs=1.00 sw_exec=274.5  legs_max=3 legs_p99=1  sw_max=1416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.17 ms/shot (wall 217s)  legs=1.00 sw_exec=274.5  legs_max=3 legs_p99=1  sw_max=1416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.17 ms/shot (wall 217s)  legs=1.00 sw_exec=274.5  legs_max=3 legs_p99=1  sw_max=1416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.17 ms/shot (wall 217s)  legs=1.00 sw_exec=274.5  legs_max=3 legs_p99=1  sw_max=1416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.17 ms/shot (wall 217s)  legs=1.00 sw_exec=274.5  legs_max=3 legs_p99=1  sw_max=1416 sw_p99=500
## shard k=36 seed=300000036 shots=4000 Tue Jun 23 04:03:09 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.99 ms/shot (wall 216s)  legs=1.00 sw_exec=284.3  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.99 ms/shot (wall 216s)  legs=1.00 sw_exec=284.3  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.99 ms/shot (wall 216s)  legs=1.00 sw_exec=284.3  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.99 ms/shot (wall 216s)  legs=1.00 sw_exec=284.3  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.99 ms/shot (wall 216s)  legs=1.00 sw_exec=284.3  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
## shard k=37 seed=300000037 shots=4000 Tue Jun 23 04:06:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.32 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.32 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.32 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.32 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.32 ms/shot (wall 201s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=38 seed=300000038 shots=4000 Tue Jun 23 04:10:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=264.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=264.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=264.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=264.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=264.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=39 seed=300000039 shots=4000 Tue Jun 23 04:13:26 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.80 ms/shot (wall 199s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.80 ms/shot (wall 199s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.80 ms/shot (wall 199s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.80 ms/shot (wall 199s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.80 ms/shot (wall 199s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=40 seed=300000040 shots=4000 Tue Jun 23 04:17:21 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  57.83 ms/shot (wall 231s)  legs=1.00 sw_exec=264.9  legs_max=6 legs_p99=1  sw_max=2756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  57.83 ms/shot (wall 231s)  legs=1.00 sw_exec=264.9  legs_max=6 legs_p99=1  sw_max=2756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  57.83 ms/shot (wall 231s)  legs=1.00 sw_exec=264.9  legs_max=6 legs_p99=1  sw_max=2756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  57.83 ms/shot (wall 231s)  legs=1.00 sw_exec=264.9  legs_max=6 legs_p99=1  sw_max=2756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  57.83 ms/shot (wall 231s)  legs=1.00 sw_exec=264.9  legs_max=6 legs_p99=1  sw_max=2756 sw_p99=500
## shard k=41 seed=300000041 shots=4000 Tue Jun 23 04:20:58 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.39 ms/shot (wall 214s)  legs=1.00 sw_exec=251.2  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.39 ms/shot (wall 214s)  legs=1.00 sw_exec=251.2  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.39 ms/shot (wall 214s)  legs=1.00 sw_exec=251.2  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.39 ms/shot (wall 214s)  legs=1.00 sw_exec=251.2  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.39 ms/shot (wall 214s)  legs=1.00 sw_exec=251.2  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
## shard k=42 seed=300000042 shots=4000 Tue Jun 23 04:24:23 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=43 seed=300000043 shots=4000 Tue Jun 23 04:27:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.66 ms/shot (wall 211s)  legs=1.00 sw_exec=255.0  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.66 ms/shot (wall 211s)  legs=1.00 sw_exec=255.0  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.66 ms/shot (wall 211s)  legs=1.00 sw_exec=255.0  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.66 ms/shot (wall 211s)  legs=1.00 sw_exec=255.0  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.66 ms/shot (wall 211s)  legs=1.00 sw_exec=255.0  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
## shard k=44 seed=300000044 shots=4000 Tue Jun 23 04:31:22 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=45 seed=300000045 shots=4000 Tue Jun 23 04:37:47 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  95.28 ms/shot (wall 381s)  legs=1.01 sw_exec=300.4  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  95.28 ms/shot (wall 381s)  legs=1.01 sw_exec=300.4  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  95.28 ms/shot (wall 381s)  legs=1.01 sw_exec=300.4  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  95.28 ms/shot (wall 381s)  legs=1.01 sw_exec=300.4  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  95.28 ms/shot (wall 381s)  legs=1.01 sw_exec=300.4  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=46 seed=300000046 shots=4000 Tue Jun 23 04:41:12 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.53 ms/shot (wall 202s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=47 seed=300000047 shots=4000 Tue Jun 23 04:44:40 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.23 ms/shot (wall 205s)  legs=1.00 sw_exec=258.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.23 ms/shot (wall 205s)  legs=1.00 sw_exec=258.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.23 ms/shot (wall 205s)  legs=1.00 sw_exec=258.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.23 ms/shot (wall 205s)  legs=1.00 sw_exec=258.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.23 ms/shot (wall 205s)  legs=1.00 sw_exec=258.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=48 seed=300000048 shots=4000 Tue Jun 23 04:48:09 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.30 ms/shot (wall 205s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.30 ms/shot (wall 205s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.30 ms/shot (wall 205s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.30 ms/shot (wall 205s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.30 ms/shot (wall 205s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=49 seed=300000049 shots=4000 Tue Jun 23 04:51:38 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.59 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.59 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.59 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.59 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.59 ms/shot (wall 206s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=50 seed=300000050 shots=4000 Tue Jun 23 04:55:05 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.75 ms/shot (wall 203s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.75 ms/shot (wall 203s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.75 ms/shot (wall 203s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.75 ms/shot (wall 203s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.75 ms/shot (wall 203s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=51 seed=300000051 shots=4000 Tue Jun 23 04:58:36 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.08 ms/shot (wall 208s)  legs=1.00 sw_exec=255.0  legs_max=2 legs_p99=1  sw_max=1000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.08 ms/shot (wall 208s)  legs=1.00 sw_exec=255.0  legs_max=2 legs_p99=1  sw_max=1000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.08 ms/shot (wall 208s)  legs=1.00 sw_exec=255.0  legs_max=2 legs_p99=1  sw_max=1000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.08 ms/shot (wall 208s)  legs=1.00 sw_exec=255.0  legs_max=2 legs_p99=1  sw_max=1000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.08 ms/shot (wall 208s)  legs=1.00 sw_exec=255.0  legs_max=2 legs_p99=1  sw_max=1000 sw_p99=500
## shard k=52 seed=300000052 shots=4000 Tue Jun 23 05:02:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.16 ms/shot (wall 205s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.16 ms/shot (wall 205s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.16 ms/shot (wall 205s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.16 ms/shot (wall 205s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.16 ms/shot (wall 205s)  legs=1.00 sw_exec=263.5  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=53 seed=300000053 shots=4000 Tue Jun 23 05:05:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.72 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=54 seed=300000054 shots=4000 Tue Jun 23 05:08:58 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.15 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=55 seed=300000055 shots=4000 Tue Jun 23 05:12:29 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=277.4  legs_max=1 legs_p99=1  sw_max=448 sw_p99=448
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=277.4  legs_max=1 legs_p99=1  sw_max=448 sw_p99=448
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=277.4  legs_max=1 legs_p99=1  sw_max=448 sw_p99=448
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=277.4  legs_max=1 legs_p99=1  sw_max=448 sw_p99=448
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=277.4  legs_max=1 legs_p99=1  sw_max=448 sw_p99=448
## shard k=56 seed=300000056 shots=4000 Tue Jun 23 05:16:19 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.70 ms/shot (wall 227s)  legs=1.00 sw_exec=274.7  legs_max=5 legs_p99=1  sw_max=2224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.70 ms/shot (wall 227s)  legs=1.00 sw_exec=274.7  legs_max=5 legs_p99=1  sw_max=2224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.70 ms/shot (wall 227s)  legs=1.00 sw_exec=274.7  legs_max=5 legs_p99=1  sw_max=2224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.70 ms/shot (wall 227s)  legs=1.00 sw_exec=274.7  legs_max=5 legs_p99=1  sw_max=2224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.70 ms/shot (wall 227s)  legs=1.00 sw_exec=274.7  legs_max=5 legs_p99=1  sw_max=2224 sw_p99=500
## shard k=57 seed=300000057 shots=4000 Tue Jun 23 05:19:41 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.74 ms/shot (wall 199s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=256 sw_p99=256
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.74 ms/shot (wall 199s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=256 sw_p99=256
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.74 ms/shot (wall 199s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=256 sw_p99=256
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.74 ms/shot (wall 199s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=256 sw_p99=256
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.74 ms/shot (wall 199s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=256 sw_p99=256
## shard k=58 seed=300000058 shots=4000 Tue Jun 23 05:23:17 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.17 ms/shot (wall 213s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.17 ms/shot (wall 213s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.17 ms/shot (wall 213s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.17 ms/shot (wall 213s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.17 ms/shot (wall 213s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1288 sw_p99=500
## shard k=59 seed=300000059 shots=4000 Tue Jun 23 05:26:41 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.25 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.25 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.25 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.25 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.25 ms/shot (wall 201s)  legs=1.00 sw_exec=247.7  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=60 seed=300000060 shots=4000 Tue Jun 23 05:31:15 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  67.57 ms/shot (wall 270s)  legs=1.00 sw_exec=270.0  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  67.57 ms/shot (wall 270s)  legs=1.00 sw_exec=270.0  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  67.57 ms/shot (wall 270s)  legs=1.00 sw_exec=270.0  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  67.57 ms/shot (wall 270s)  legs=1.00 sw_exec=270.0  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  67.57 ms/shot (wall 270s)  legs=1.00 sw_exec=270.0  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
## shard k=61 seed=300000061 shots=4000 Tue Jun 23 05:34:41 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.56 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.56 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.56 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.56 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.56 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=62 seed=300000062 shots=4000 Tue Jun 23 05:39:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.13 ms/shot (wall 261s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.13 ms/shot (wall 261s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.13 ms/shot (wall 261s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.13 ms/shot (wall 261s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.13 ms/shot (wall 261s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5192 sw_p99=500
## shard k=63 seed=300000063 shots=4000 Tue Jun 23 05:42:33 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.22 ms/shot (wall 205s)  legs=1.00 sw_exec=266.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.22 ms/shot (wall 205s)  legs=1.00 sw_exec=266.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.22 ms/shot (wall 205s)  legs=1.00 sw_exec=266.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.22 ms/shot (wall 205s)  legs=1.00 sw_exec=266.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.22 ms/shot (wall 205s)  legs=1.00 sw_exec=266.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=64 seed=300000064 shots=4000 Tue Jun 23 05:45:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=65 seed=300000065 shots=4000 Tue Jun 23 05:49:47 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.74 ms/shot (wall 227s)  legs=1.00 sw_exec=275.2  legs_max=5 legs_p99=1  sw_max=2160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.74 ms/shot (wall 227s)  legs=1.00 sw_exec=275.2  legs_max=5 legs_p99=1  sw_max=2160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.74 ms/shot (wall 227s)  legs=1.00 sw_exec=275.2  legs_max=5 legs_p99=1  sw_max=2160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.74 ms/shot (wall 227s)  legs=1.00 sw_exec=275.2  legs_max=5 legs_p99=1  sw_max=2160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.74 ms/shot (wall 227s)  legs=1.00 sw_exec=275.2  legs_max=5 legs_p99=1  sw_max=2160 sw_p99=500
## shard k=66 seed=300000066 shots=4000 Tue Jun 23 05:53:17 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.70 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.70 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.70 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.70 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.70 ms/shot (wall 207s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=67 seed=300000067 shots=4000 Tue Jun 23 05:59:27 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  91.50 ms/shot (wall 366s)  legs=1.01 sw_exec=309.5  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  91.50 ms/shot (wall 366s)  legs=1.01 sw_exec=309.5  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  91.50 ms/shot (wall 366s)  legs=1.01 sw_exec=309.5  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  91.50 ms/shot (wall 366s)  legs=1.01 sw_exec=309.5  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  91.50 ms/shot (wall 366s)  legs=1.01 sw_exec=309.5  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=68 seed=300000068 shots=4000 Tue Jun 23 06:03:13 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  55.89 ms/shot (wall 224s)  legs=1.00 sw_exec=262.8  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  55.89 ms/shot (wall 224s)  legs=1.00 sw_exec=262.8  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  55.89 ms/shot (wall 224s)  legs=1.00 sw_exec=262.8  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  55.89 ms/shot (wall 224s)  legs=1.00 sw_exec=262.8  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  55.89 ms/shot (wall 224s)  legs=1.00 sw_exec=262.8  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
## shard k=69 seed=300000069 shots=4000 Tue Jun 23 06:06:36 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.73 ms/shot (wall 199s)  legs=1.00 sw_exec=241.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.73 ms/shot (wall 199s)  legs=1.00 sw_exec=241.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.73 ms/shot (wall 199s)  legs=1.00 sw_exec=241.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.73 ms/shot (wall 199s)  legs=1.00 sw_exec=241.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.73 ms/shot (wall 199s)  legs=1.00 sw_exec=241.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=70 seed=300000070 shots=4000 Tue Jun 23 06:10:00 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.30 ms/shot (wall 201s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=71 seed=300000071 shots=4000 Tue Jun 23 06:13:33 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.30 ms/shot (wall 209s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.30 ms/shot (wall 209s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.30 ms/shot (wall 209s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.30 ms/shot (wall 209s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.30 ms/shot (wall 209s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=72 seed=300000072 shots=4000 Tue Jun 23 06:17:03 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.64 ms/shot (wall 207s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.64 ms/shot (wall 207s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.64 ms/shot (wall 207s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.64 ms/shot (wall 207s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.64 ms/shot (wall 207s)  legs=1.00 sw_exec=260.9  legs_max=2 legs_p99=1  sw_max=756 sw_p99=500
## shard k=73 seed=300000073 shots=4000 Tue Jun 23 06:20:31 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=252.9  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=252.9  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=252.9  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=252.9  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=252.9  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=74 seed=300000074 shots=4000 Tue Jun 23 06:26:54 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  94.88 ms/shot (wall 380s)  legs=1.01 sw_exec=288.9  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  94.88 ms/shot (wall 380s)  legs=1.01 sw_exec=288.9  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  94.88 ms/shot (wall 380s)  legs=1.01 sw_exec=288.9  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  94.88 ms/shot (wall 380s)  legs=1.01 sw_exec=288.9  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  94.88 ms/shot (wall 380s)  legs=1.01 sw_exec=288.9  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=75 seed=300000075 shots=4000 Tue Jun 23 06:30:37 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.10 ms/shot (wall 220s)  legs=1.00 sw_exec=273.8  legs_max=3 legs_p99=1  sw_max=1480 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.10 ms/shot (wall 220s)  legs=1.00 sw_exec=273.8  legs_max=3 legs_p99=1  sw_max=1480 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.10 ms/shot (wall 220s)  legs=1.00 sw_exec=273.8  legs_max=3 legs_p99=1  sw_max=1480 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.10 ms/shot (wall 220s)  legs=1.00 sw_exec=273.8  legs_max=3 legs_p99=1  sw_max=1480 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.10 ms/shot (wall 220s)  legs=1.00 sw_exec=273.8  legs_max=3 legs_p99=1  sw_max=1480 sw_p99=500
## shard k=76 seed=300000076 shots=4000 Tue Jun 23 06:34:03 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.57 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.57 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.57 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.57 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.57 ms/shot (wall 202s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=77 seed=300000077 shots=4000 Tue Jun 23 06:38:00 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  58.40 ms/shot (wall 234s)  legs=1.00 sw_exec=290.2  legs_max=4 legs_p99=1  sw_max=1692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  58.40 ms/shot (wall 234s)  legs=1.00 sw_exec=290.2  legs_max=4 legs_p99=1  sw_max=1692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  58.40 ms/shot (wall 234s)  legs=1.00 sw_exec=290.2  legs_max=4 legs_p99=1  sw_max=1692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  58.40 ms/shot (wall 234s)  legs=1.00 sw_exec=290.2  legs_max=4 legs_p99=1  sw_max=1692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  58.40 ms/shot (wall 234s)  legs=1.00 sw_exec=290.2  legs_max=4 legs_p99=1  sw_max=1692 sw_p99=500
## shard k=78 seed=300000078 shots=4000 Tue Jun 23 06:41:23 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.98 ms/shot (wall 200s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.98 ms/shot (wall 200s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.98 ms/shot (wall 200s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.98 ms/shot (wall 200s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  49.98 ms/shot (wall 200s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=79 seed=300000079 shots=4000 Tue Jun 23 06:44:51 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.14 ms/shot (wall 205s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
## shard k=80 seed=300000080 shots=4000 Tue Jun 23 06:48:20 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.47 ms/shot (wall 206s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.47 ms/shot (wall 206s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.47 ms/shot (wall 206s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.47 ms/shot (wall 206s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.47 ms/shot (wall 206s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=81 seed=300000081 shots=4000 Tue Jun 23 06:53:10 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  71.61 ms/shot (wall 286s)  legs=1.00 sw_exec=294.1  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  71.61 ms/shot (wall 286s)  legs=1.00 sw_exec=294.1  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  71.61 ms/shot (wall 286s)  legs=1.00 sw_exec=294.1  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  71.61 ms/shot (wall 286s)  legs=1.00 sw_exec=294.1  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  71.61 ms/shot (wall 286s)  legs=1.00 sw_exec=294.1  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
## shard k=82 seed=300000082 shots=4000 Tue Jun 23 06:56:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.77 ms/shot (wall 199s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.77 ms/shot (wall 199s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.77 ms/shot (wall 199s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.77 ms/shot (wall 199s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.77 ms/shot (wall 199s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=83 seed=300000083 shots=4000 Tue Jun 23 07:00:28 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  57.95 ms/shot (wall 232s)  legs=1.00 sw_exec=302.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  57.95 ms/shot (wall 232s)  legs=1.00 sw_exec=302.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  57.95 ms/shot (wall 232s)  legs=1.00 sw_exec=302.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  57.95 ms/shot (wall 232s)  legs=1.00 sw_exec=302.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  57.95 ms/shot (wall 232s)  legs=1.00 sw_exec=302.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
## shard k=84 seed=300000084 shots=4000 Tue Jun 23 07:03:50 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.76 ms/shot (wall 199s)  legs=1.00 sw_exec=235.9  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.76 ms/shot (wall 199s)  legs=1.00 sw_exec=235.9  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.76 ms/shot (wall 199s)  legs=1.00 sw_exec=235.9  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.76 ms/shot (wall 199s)  legs=1.00 sw_exec=235.9  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.76 ms/shot (wall 199s)  legs=1.00 sw_exec=235.9  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=85 seed=300000085 shots=4000 Tue Jun 23 07:07:15 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.41 ms/shot (wall 202s)  legs=1.00 sw_exec=253.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=86 seed=300000086 shots=4000 Tue Jun 23 07:10:40 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.55 ms/shot (wall 202s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.55 ms/shot (wall 202s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.55 ms/shot (wall 202s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.55 ms/shot (wall 202s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.55 ms/shot (wall 202s)  legs=1.00 sw_exec=252.0  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=87 seed=300000087 shots=4000 Tue Jun 23 07:14:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.16 ms/shot (wall 201s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=88 seed=300000088 shots=4000 Tue Jun 23 07:17:30 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=89 seed=300000089 shots=4000 Tue Jun 23 07:21:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  59.76 ms/shot (wall 239s)  legs=1.00 sw_exec=263.5  legs_max=7 legs_p99=1  sw_max=3416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  59.76 ms/shot (wall 239s)  legs=1.00 sw_exec=263.5  legs_max=7 legs_p99=1  sw_max=3416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  59.76 ms/shot (wall 239s)  legs=1.00 sw_exec=263.5  legs_max=7 legs_p99=1  sw_max=3416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  59.76 ms/shot (wall 239s)  legs=1.00 sw_exec=263.5  legs_max=7 legs_p99=1  sw_max=3416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  59.76 ms/shot (wall 239s)  legs=1.00 sw_exec=263.5  legs_max=7 legs_p99=1  sw_max=3416 sw_p99=500
## shard k=90 seed=300000090 shots=4000 Tue Jun 23 07:24:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.31 ms/shot (wall 201s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=91 seed=300000091 shots=4000 Tue Jun 23 07:28:22 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.39 ms/shot (wall 202s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=92 seed=300000092 shots=4000 Tue Jun 23 07:31:59 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.40 ms/shot (wall 214s)  legs=1.00 sw_exec=276.4  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.40 ms/shot (wall 214s)  legs=1.00 sw_exec=276.4  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.40 ms/shot (wall 214s)  legs=1.00 sw_exec=276.4  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.40 ms/shot (wall 214s)  legs=1.00 sw_exec=276.4  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.40 ms/shot (wall 214s)  legs=1.00 sw_exec=276.4  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
## shard k=93 seed=300000093 shots=4000 Tue Jun 23 07:35:22 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.04 ms/shot (wall 200s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.04 ms/shot (wall 200s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.04 ms/shot (wall 200s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.04 ms/shot (wall 200s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.04 ms/shot (wall 200s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=94 seed=300000094 shots=4000 Tue Jun 23 07:38:51 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.33 ms/shot (wall 205s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.33 ms/shot (wall 205s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.33 ms/shot (wall 205s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.33 ms/shot (wall 205s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.33 ms/shot (wall 205s)  legs=1.00 sw_exec=258.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=95 seed=300000095 shots=4000 Tue Jun 23 07:42:16 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=250.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=250.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=250.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=250.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.35 ms/shot (wall 201s)  legs=1.00 sw_exec=250.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=96 seed=300000096 shots=4000 Tue Jun 23 07:45:40 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.17 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.17 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.17 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.17 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.17 ms/shot (wall 201s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
## shard k=97 seed=300000097 shots=4000 Tue Jun 23 07:49:11 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.99 ms/shot (wall 208s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.99 ms/shot (wall 208s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.99 ms/shot (wall 208s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.99 ms/shot (wall 208s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.99 ms/shot (wall 208s)  legs=1.00 sw_exec=274.7  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=98 seed=300000098 shots=4000 Tue Jun 23 07:52:37 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=253.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=99 seed=300000099 shots=4000 Tue Jun 23 07:56:00 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.92 ms/shot (wall 200s)  legs=1.00 sw_exec=237.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.92 ms/shot (wall 200s)  legs=1.00 sw_exec=237.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.92 ms/shot (wall 200s)  legs=1.00 sw_exec=237.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.92 ms/shot (wall 200s)  legs=1.00 sw_exec=237.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  49.92 ms/shot (wall 200s)  legs=1.00 sw_exec=237.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=100 seed=300000100 shots=4000 Tue Jun 23 07:59:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.67 ms/shot (wall 211s)  legs=1.00 sw_exec=264.9  legs_max=2 legs_p99=1  sw_max=948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.67 ms/shot (wall 211s)  legs=1.00 sw_exec=264.9  legs_max=2 legs_p99=1  sw_max=948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.67 ms/shot (wall 211s)  legs=1.00 sw_exec=264.9  legs_max=2 legs_p99=1  sw_max=948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.67 ms/shot (wall 211s)  legs=1.00 sw_exec=264.9  legs_max=2 legs_p99=1  sw_max=948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.67 ms/shot (wall 211s)  legs=1.00 sw_exec=264.9  legs_max=2 legs_p99=1  sw_max=948 sw_p99=500
## shard k=101 seed=300000101 shots=4000 Tue Jun 23 08:03:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.79 ms/shot (wall 227s)  legs=1.00 sw_exec=267.2  legs_max=5 legs_p99=1  sw_max=2320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.79 ms/shot (wall 227s)  legs=1.00 sw_exec=267.2  legs_max=5 legs_p99=1  sw_max=2320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.79 ms/shot (wall 227s)  legs=1.00 sw_exec=267.2  legs_max=5 legs_p99=1  sw_max=2320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.79 ms/shot (wall 227s)  legs=1.00 sw_exec=267.2  legs_max=5 legs_p99=1  sw_max=2320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  56.79 ms/shot (wall 227s)  legs=1.00 sw_exec=267.2  legs_max=5 legs_p99=1  sw_max=2320 sw_p99=500
## shard k=102 seed=300000102 shots=4000 Tue Jun 23 08:06:59 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.72 ms/shot (wall 211s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.72 ms/shot (wall 211s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.72 ms/shot (wall 211s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.72 ms/shot (wall 211s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.72 ms/shot (wall 211s)  legs=1.00 sw_exec=260.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
