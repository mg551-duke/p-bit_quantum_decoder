# worker correlated_g1 start Tue Jun 23 01:50:24 PM PDT 2026 chunk=4000 base=200000000 args: --device cuda --chains 128 --sweeps 500 --max-legs 24 --rho-scales 0.30 --gamma 1.0 --selection min_weight --capture-targets 1,2,3,4,5
## shard k=0 seed=200000000 shots=4000 Tue Jun 23 01:54:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  63.58 ms/shot (wall 254s)  legs=1.00 sw_exec=294.6  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  63.58 ms/shot (wall 254s)  legs=1.00 sw_exec=294.6  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  63.58 ms/shot (wall 254s)  legs=1.00 sw_exec=294.6  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  63.58 ms/shot (wall 254s)  legs=1.00 sw_exec=294.6  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  63.58 ms/shot (wall 254s)  legs=1.00 sw_exec=294.6  legs_max=8 legs_p99=1  sw_max=3916 sw_p99=500
## shard k=1 seed=200000001 shots=4000 Tue Jun 23 01:59:06 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  64.52 ms/shot (wall 258s)  legs=1.00 sw_exec=288.7  legs_max=9 legs_p99=1  sw_max=4256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  64.52 ms/shot (wall 258s)  legs=1.00 sw_exec=288.7  legs_max=9 legs_p99=1  sw_max=4256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  64.52 ms/shot (wall 258s)  legs=1.00 sw_exec=288.7  legs_max=9 legs_p99=1  sw_max=4256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  64.52 ms/shot (wall 258s)  legs=1.00 sw_exec=288.7  legs_max=9 legs_p99=1  sw_max=4256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  64.52 ms/shot (wall 258s)  legs=1.00 sw_exec=288.7  legs_max=9 legs_p99=1  sw_max=4256 sw_p99=500
## shard k=2 seed=200000002 shots=4000 Tue Jun 23 02:02:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.59 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=3 seed=200000003 shots=4000 Tue Jun 23 02:06:03 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.05 ms/shot (wall 208s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.05 ms/shot (wall 208s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.05 ms/shot (wall 208s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.05 ms/shot (wall 208s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.05 ms/shot (wall 208s)  legs=1.00 sw_exec=275.0  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
## shard k=4 seed=200000004 shots=4000 Tue Jun 23 02:09:53 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  56.47 ms/shot (wall 226s)  legs=1.00 sw_exec=282.9  legs_max=4 legs_p99=1  sw_max=1788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  56.47 ms/shot (wall 226s)  legs=1.00 sw_exec=282.9  legs_max=4 legs_p99=1  sw_max=1788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  56.47 ms/shot (wall 226s)  legs=1.00 sw_exec=282.9  legs_max=4 legs_p99=1  sw_max=1788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  56.47 ms/shot (wall 226s)  legs=1.00 sw_exec=282.9  legs_max=4 legs_p99=1  sw_max=1788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  56.47 ms/shot (wall 226s)  legs=1.00 sw_exec=282.9  legs_max=4 legs_p99=1  sw_max=1788 sw_p99=500
## shard k=5 seed=200000005 shots=4000 Tue Jun 23 02:15:50 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.40 ms/shot (wall 354s)  legs=1.01 sw_exec=282.8  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.40 ms/shot (wall 354s)  legs=1.01 sw_exec=282.8  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.40 ms/shot (wall 354s)  legs=1.01 sw_exec=282.8  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.40 ms/shot (wall 354s)  legs=1.01 sw_exec=282.8  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.40 ms/shot (wall 354s)  legs=1.01 sw_exec=282.8  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=6 seed=200000006 shots=4000 Tue Jun 23 02:19:15 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.40 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.40 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.40 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.40 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.40 ms/shot (wall 202s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=7 seed=200000007 shots=4000 Tue Jun 23 02:22:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=256.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=256.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=256.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=256.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.85 ms/shot (wall 207s)  legs=1.00 sw_exec=256.5  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=8 seed=200000008 shots=4000 Tue Jun 23 02:26:11 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.52 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=9 seed=200000009 shots=4000 Tue Jun 23 02:29:38 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=10 seed=200000010 shots=4000 Tue Jun 23 02:33:07 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=261.5  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=261.5  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=261.5  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=261.5  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.60 ms/shot (wall 206s)  legs=1.00 sw_exec=261.5  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
## shard k=11 seed=200000011 shots=4000 Tue Jun 23 02:36:46 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.93 ms/shot (wall 216s)  legs=1.00 sw_exec=266.9  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.93 ms/shot (wall 216s)  legs=1.00 sw_exec=266.9  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.93 ms/shot (wall 216s)  legs=1.00 sw_exec=266.9  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.93 ms/shot (wall 216s)  legs=1.00 sw_exec=266.9  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.93 ms/shot (wall 216s)  legs=1.00 sw_exec=266.9  legs_max=3 legs_p99=1  sw_max=1224 sw_p99=500
## shard k=12 seed=200000012 shots=4000 Tue Jun 23 02:42:37 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  86.80 ms/shot (wall 347s)  legs=1.01 sw_exec=265.3  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  86.80 ms/shot (wall 347s)  legs=1.01 sw_exec=265.3  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  86.80 ms/shot (wall 347s)  legs=1.01 sw_exec=265.3  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  86.80 ms/shot (wall 347s)  legs=1.01 sw_exec=265.3  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  86.80 ms/shot (wall 347s)  legs=1.01 sw_exec=265.3  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=13 seed=200000013 shots=4000 Tue Jun 23 02:46:02 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.43 ms/shot (wall 202s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.43 ms/shot (wall 202s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.43 ms/shot (wall 202s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.43 ms/shot (wall 202s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.43 ms/shot (wall 202s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=14 seed=200000014 shots=4000 Tue Jun 23 02:49:30 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.28 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.28 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.28 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.28 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.28 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=15 seed=200000015 shots=4000 Tue Jun 23 02:55:27 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.26 ms/shot (wall 353s)  legs=1.01 sw_exec=275.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.26 ms/shot (wall 353s)  legs=1.01 sw_exec=275.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.26 ms/shot (wall 353s)  legs=1.01 sw_exec=275.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.26 ms/shot (wall 353s)  legs=1.01 sw_exec=275.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  88.26 ms/shot (wall 353s)  legs=1.01 sw_exec=275.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=16 seed=200000016 shots=4000 Tue Jun 23 02:58:53 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.92 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=17 seed=200000017 shots=4000 Tue Jun 23 03:02:30 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.30 ms/shot (wall 213s)  legs=1.00 sw_exec=273.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.30 ms/shot (wall 213s)  legs=1.00 sw_exec=273.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.30 ms/shot (wall 213s)  legs=1.00 sw_exec=273.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.30 ms/shot (wall 213s)  legs=1.00 sw_exec=273.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.30 ms/shot (wall 213s)  legs=1.00 sw_exec=273.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=18 seed=200000018 shots=4000 Tue Jun 23 03:05:55 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.42 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.42 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.42 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.42 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.42 ms/shot (wall 202s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=19 seed=200000019 shots=4000 Tue Jun 23 03:09:22 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.98 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.98 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.98 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.98 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.98 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=20 seed=200000020 shots=4000 Tue Jun 23 03:12:49 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=246.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=246.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=246.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=246.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=246.1  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=21 seed=200000021 shots=4000 Tue Jun 23 03:16:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.24 ms/shot (wall 213s)  legs=1.00 sw_exec=257.0  legs_max=3 legs_p99=1  sw_max=1160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.24 ms/shot (wall 213s)  legs=1.00 sw_exec=257.0  legs_max=3 legs_p99=1  sw_max=1160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.24 ms/shot (wall 213s)  legs=1.00 sw_exec=257.0  legs_max=3 legs_p99=1  sw_max=1160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.24 ms/shot (wall 213s)  legs=1.00 sw_exec=257.0  legs_max=3 legs_p99=1  sw_max=1160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  53.24 ms/shot (wall 213s)  legs=1.00 sw_exec=257.0  legs_max=3 legs_p99=1  sw_max=1160 sw_p99=500
## shard k=22 seed=200000022 shots=4000 Tue Jun 23 03:19:51 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.64 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.64 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.64 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.64 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.64 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=23 seed=200000023 shots=4000 Tue Jun 23 03:24:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  70.02 ms/shot (wall 280s)  legs=1.00 sw_exec=285.2  legs_max=13 legs_p99=1  sw_max=6160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  70.02 ms/shot (wall 280s)  legs=1.00 sw_exec=285.2  legs_max=13 legs_p99=1  sw_max=6160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  70.02 ms/shot (wall 280s)  legs=1.00 sw_exec=285.2  legs_max=13 legs_p99=1  sw_max=6160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  70.02 ms/shot (wall 280s)  legs=1.00 sw_exec=285.2  legs_max=13 legs_p99=1  sw_max=6160 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  70.02 ms/shot (wall 280s)  legs=1.00 sw_exec=285.2  legs_max=13 legs_p99=1  sw_max=6160 sw_p99=500
## shard k=24 seed=200000024 shots=4000 Tue Jun 23 03:28:10 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.12 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.12 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.12 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.12 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  53.12 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=788 sw_p99=500
## shard k=25 seed=200000025 shots=4000 Tue Jun 23 03:31:38 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.19 ms/shot (wall 205s)  legs=1.00 sw_exec=258.4  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.19 ms/shot (wall 205s)  legs=1.00 sw_exec=258.4  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.19 ms/shot (wall 205s)  legs=1.00 sw_exec=258.4  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.19 ms/shot (wall 205s)  legs=1.00 sw_exec=258.4  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.19 ms/shot (wall 205s)  legs=1.00 sw_exec=258.4  legs_max=1 legs_p99=1  sw_max=500 sw_p99=500
## shard k=26 seed=200000026 shots=4000 Tue Jun 23 03:35:05 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=249.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=27 seed=200000027 shots=4000 Tue Jun 23 03:38:36 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.77 ms/shot (wall 207s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.77 ms/shot (wall 207s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.77 ms/shot (wall 207s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.77 ms/shot (wall 207s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.77 ms/shot (wall 207s)  legs=1.00 sw_exec=261.9  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=28 seed=200000028 shots=4000 Tue Jun 23 03:42:03 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.10 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.10 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.10 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.10 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.10 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=29 seed=200000029 shots=4000 Tue Jun 23 03:46:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  66.41 ms/shot (wall 266s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  66.41 ms/shot (wall 266s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  66.41 ms/shot (wall 266s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  66.41 ms/shot (wall 266s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5320 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  66.41 ms/shot (wall 266s)  legs=1.00 sw_exec=263.6  legs_max=11 legs_p99=1  sw_max=5320 sw_p99=500
## shard k=30 seed=200000030 shots=4000 Tue Jun 23 03:50:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.04 ms/shot (wall 208s)  legs=1.00 sw_exec=260.5  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.04 ms/shot (wall 208s)  legs=1.00 sw_exec=260.5  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.04 ms/shot (wall 208s)  legs=1.00 sw_exec=260.5  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.04 ms/shot (wall 208s)  legs=1.00 sw_exec=260.5  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.04 ms/shot (wall 208s)  legs=1.00 sw_exec=260.5  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=31 seed=200000031 shots=4000 Tue Jun 23 03:53:36 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.34 ms/shot (wall 209s)  legs=1.00 sw_exec=268.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.34 ms/shot (wall 209s)  legs=1.00 sw_exec=268.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.34 ms/shot (wall 209s)  legs=1.00 sw_exec=268.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.34 ms/shot (wall 209s)  legs=1.00 sw_exec=268.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.34 ms/shot (wall 209s)  legs=1.00 sw_exec=268.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=32 seed=200000032 shots=4000 Tue Jun 23 03:57:05 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.35 ms/shot (wall 205s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.35 ms/shot (wall 205s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.35 ms/shot (wall 205s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.35 ms/shot (wall 205s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.35 ms/shot (wall 205s)  legs=1.00 sw_exec=259.6  legs_max=1 legs_p99=1  sw_max=480 sw_p99=480
## shard k=33 seed=200000033 shots=4000 Tue Jun 23 04:00:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.15 ms/shot (wall 217s)  legs=1.00 sw_exec=272.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.15 ms/shot (wall 217s)  legs=1.00 sw_exec=272.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.15 ms/shot (wall 217s)  legs=1.00 sw_exec=272.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.15 ms/shot (wall 217s)  legs=1.00 sw_exec=272.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.15 ms/shot (wall 217s)  legs=1.00 sw_exec=272.8  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
## shard k=34 seed=200000034 shots=4000 Tue Jun 23 04:04:52 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  60.84 ms/shot (wall 243s)  legs=1.00 sw_exec=298.2  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  60.84 ms/shot (wall 243s)  legs=1.00 sw_exec=298.2  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  60.84 ms/shot (wall 243s)  legs=1.00 sw_exec=298.2  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  60.84 ms/shot (wall 243s)  legs=1.00 sw_exec=298.2  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  60.84 ms/shot (wall 243s)  legs=1.00 sw_exec=298.2  legs_max=5 legs_p99=1  sw_max=2192 sw_p99=500
## shard k=35 seed=200000035 shots=4000 Tue Jun 23 04:08:18 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.70 ms/shot (wall 203s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.70 ms/shot (wall 203s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.70 ms/shot (wall 203s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.70 ms/shot (wall 203s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.70 ms/shot (wall 203s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=36 seed=200000036 shots=4000 Tue Jun 23 04:11:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.04 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.04 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.04 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.04 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.04 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=37 seed=200000037 shots=4000 Tue Jun 23 04:15:13 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.99 ms/shot (wall 204s)  legs=1.00 sw_exec=246.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.99 ms/shot (wall 204s)  legs=1.00 sw_exec=246.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.99 ms/shot (wall 204s)  legs=1.00 sw_exec=246.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.99 ms/shot (wall 204s)  legs=1.00 sw_exec=246.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.99 ms/shot (wall 204s)  legs=1.00 sw_exec=246.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=38 seed=200000038 shots=4000 Tue Jun 23 04:18:43 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.79 ms/shot (wall 207s)  legs=1.00 sw_exec=269.4  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.79 ms/shot (wall 207s)  legs=1.00 sw_exec=269.4  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.79 ms/shot (wall 207s)  legs=1.00 sw_exec=269.4  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.79 ms/shot (wall 207s)  legs=1.00 sw_exec=269.4  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.79 ms/shot (wall 207s)  legs=1.00 sw_exec=269.4  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
## shard k=39 seed=200000039 shots=4000 Tue Jun 23 04:23:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  69.74 ms/shot (wall 279s)  legs=1.00 sw_exec=274.9  legs_max=12 legs_p99=1  sw_max=5948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  69.74 ms/shot (wall 279s)  legs=1.00 sw_exec=274.9  legs_max=12 legs_p99=1  sw_max=5948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  69.74 ms/shot (wall 279s)  legs=1.00 sw_exec=274.9  legs_max=12 legs_p99=1  sw_max=5948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  69.74 ms/shot (wall 279s)  legs=1.00 sw_exec=274.9  legs_max=12 legs_p99=1  sw_max=5948 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  69.74 ms/shot (wall 279s)  legs=1.00 sw_exec=274.9  legs_max=12 legs_p99=1  sw_max=5948 sw_p99=500
## shard k=40 seed=200000040 shots=4000 Tue Jun 23 04:26:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.09 ms/shot (wall 208s)  legs=1.00 sw_exec=262.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.09 ms/shot (wall 208s)  legs=1.00 sw_exec=262.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.09 ms/shot (wall 208s)  legs=1.00 sw_exec=262.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.09 ms/shot (wall 208s)  legs=1.00 sw_exec=262.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.09 ms/shot (wall 208s)  legs=1.00 sw_exec=262.8  legs_max=2 legs_p99=1  sw_max=692 sw_p99=500
## shard k=41 seed=200000041 shots=4000 Tue Jun 23 04:33:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  104.10 ms/shot (wall 416s)  legs=1.01 sw_exec=310.1  legs_max=18 legs_p99=1  sw_max=8820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  104.10 ms/shot (wall 416s)  legs=1.01 sw_exec=310.1  legs_max=18 legs_p99=1  sw_max=8820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  104.10 ms/shot (wall 416s)  legs=1.01 sw_exec=310.1  legs_max=18 legs_p99=1  sw_max=8820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  104.10 ms/shot (wall 416s)  legs=1.01 sw_exec=310.1  legs_max=18 legs_p99=1  sw_max=8820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  104.10 ms/shot (wall 416s)  legs=1.01 sw_exec=310.1  legs_max=18 legs_p99=1  sw_max=8820 sw_p99=500
## shard k=42 seed=200000042 shots=4000 Tue Jun 23 04:38:05 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  61.19 ms/shot (wall 245s)  legs=1.00 sw_exec=265.2  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  61.19 ms/shot (wall 245s)  legs=1.00 sw_exec=265.2  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  61.19 ms/shot (wall 245s)  legs=1.00 sw_exec=265.2  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  61.19 ms/shot (wall 245s)  legs=1.00 sw_exec=265.2  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  61.19 ms/shot (wall 245s)  legs=1.00 sw_exec=265.2  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
## shard k=43 seed=200000043 shots=4000 Tue Jun 23 04:41:31 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.66 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=44 seed=200000044 shots=4000 Tue Jun 23 04:44:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=242.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=242.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=242.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=242.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=242.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=45 seed=200000045 shots=4000 Tue Jun 23 04:48:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.27 ms/shot (wall 205s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.27 ms/shot (wall 205s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.27 ms/shot (wall 205s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.27 ms/shot (wall 205s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.27 ms/shot (wall 205s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=352 sw_p99=352
## shard k=46 seed=200000046 shots=4000 Tue Jun 23 04:52:25 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  59.21 ms/shot (wall 237s)  legs=1.00 sw_exec=272.9  legs_max=6 legs_p99=1  sw_max=2852 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  59.21 ms/shot (wall 237s)  legs=1.00 sw_exec=272.9  legs_max=6 legs_p99=1  sw_max=2852 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  59.21 ms/shot (wall 237s)  legs=1.00 sw_exec=272.9  legs_max=6 legs_p99=1  sw_max=2852 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  59.21 ms/shot (wall 237s)  legs=1.00 sw_exec=272.9  legs_max=6 legs_p99=1  sw_max=2852 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  59.21 ms/shot (wall 237s)  legs=1.00 sw_exec=272.9  legs_max=6 legs_p99=1  sw_max=2852 sw_p99=500
## shard k=47 seed=200000047 shots=4000 Tue Jun 23 04:58:17 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  87.08 ms/shot (wall 348s)  legs=1.01 sw_exec=271.6  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  87.08 ms/shot (wall 348s)  legs=1.01 sw_exec=271.6  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  87.08 ms/shot (wall 348s)  legs=1.01 sw_exec=271.6  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  87.08 ms/shot (wall 348s)  legs=1.01 sw_exec=271.6  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  87.08 ms/shot (wall 348s)  legs=1.01 sw_exec=271.6  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=48 seed=200000048 shots=4000 Tue Jun 23 05:01:48 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.01 ms/shot (wall 208s)  legs=1.00 sw_exec=268.7  legs_max=2 legs_p99=1  sw_max=660 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.01 ms/shot (wall 208s)  legs=1.00 sw_exec=268.7  legs_max=2 legs_p99=1  sw_max=660 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.01 ms/shot (wall 208s)  legs=1.00 sw_exec=268.7  legs_max=2 legs_p99=1  sw_max=660 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.01 ms/shot (wall 208s)  legs=1.00 sw_exec=268.7  legs_max=2 legs_p99=1  sw_max=660 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  52.01 ms/shot (wall 208s)  legs=1.00 sw_exec=268.7  legs_max=2 legs_p99=1  sw_max=660 sw_p99=500
## shard k=49 seed=200000049 shots=4000 Tue Jun 23 05:05:18 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=265.1  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=265.1  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=265.1  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=265.1  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.63 ms/shot (wall 207s)  legs=1.00 sw_exec=265.1  legs_max=1 legs_p99=1  sw_max=416 sw_p99=416
## shard k=50 seed=200000050 shots=4000 Tue Jun 23 05:09:51 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  67.49 ms/shot (wall 270s)  legs=1.00 sw_exec=258.2  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  67.49 ms/shot (wall 270s)  legs=1.00 sw_exec=258.2  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  67.49 ms/shot (wall 270s)  legs=1.00 sw_exec=258.2  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  67.49 ms/shot (wall 270s)  legs=1.00 sw_exec=258.2  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  67.49 ms/shot (wall 270s)  legs=1.00 sw_exec=258.2  legs_max=12 legs_p99=1  sw_max=5820 sw_p99=500
## shard k=51 seed=200000051 shots=4000 Tue Jun 23 05:13:20 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=257.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=52 seed=200000052 shots=4000 Tue Jun 23 05:17:04 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.35 ms/shot (wall 221s)  legs=1.00 sw_exec=302.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.35 ms/shot (wall 221s)  legs=1.00 sw_exec=302.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.35 ms/shot (wall 221s)  legs=1.00 sw_exec=302.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.35 ms/shot (wall 221s)  legs=1.00 sw_exec=302.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.35 ms/shot (wall 221s)  legs=1.00 sw_exec=302.6  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=53 seed=200000053 shots=4000 Tue Jun 23 05:20:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=251.7  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=54 seed=200000054 shots=4000 Tue Jun 23 05:23:56 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.33 ms/shot (wall 201s)  legs=1.00 sw_exec=239.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=55 seed=200000055 shots=4000 Tue Jun 23 05:27:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.01 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.01 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.01 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.01 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.01 ms/shot (wall 212s)  legs=1.00 sw_exec=278.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=56 seed=200000056 shots=4000 Tue Jun 23 05:30:58 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=240.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=240.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=240.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=240.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=240.6  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=57 seed=200000057 shots=4000 Tue Jun 23 05:34:29 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=255.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=255.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=255.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=255.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.90 ms/shot (wall 208s)  legs=1.00 sw_exec=255.3  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=58 seed=200000058 shots=4000 Tue Jun 23 05:37:56 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.97 ms/shot (wall 204s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=59 seed=200000059 shots=4000 Tue Jun 23 05:41:22 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.63 ms/shot (wall 203s)  legs=1.00 sw_exec=241.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.63 ms/shot (wall 203s)  legs=1.00 sw_exec=241.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.63 ms/shot (wall 203s)  legs=1.00 sw_exec=241.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.63 ms/shot (wall 203s)  legs=1.00 sw_exec=241.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.63 ms/shot (wall 203s)  legs=1.00 sw_exec=241.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=60 seed=200000060 shots=4000 Tue Jun 23 05:44:49 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.79 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.79 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.79 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.79 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  50.79 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=61 seed=200000061 shots=4000 Tue Jun 23 05:48:16 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.08 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.08 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.08 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.08 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.08 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=62 seed=200000062 shots=4000 Tue Jun 23 05:51:43 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.74 ms/shot (wall 203s)  legs=1.00 sw_exec=243.8  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=63 seed=200000063 shots=4000 Tue Jun 23 05:55:10 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.91 ms/shot (wall 204s)  legs=1.00 sw_exec=251.3  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=64 seed=200000064 shots=4000 Tue Jun 23 05:58:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.18 ms/shot (wall 201s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.18 ms/shot (wall 201s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.18 ms/shot (wall 201s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.18 ms/shot (wall 201s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.18 ms/shot (wall 201s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=65 seed=200000065 shots=4000 Tue Jun 23 06:02:01 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.06 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.06 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.06 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.06 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.06 ms/shot (wall 204s)  legs=1.00 sw_exec=249.7  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
## shard k=66 seed=200000066 shots=4000 Tue Jun 23 06:05:28 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.87 ms/shot (wall 203s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.87 ms/shot (wall 203s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.87 ms/shot (wall 203s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.87 ms/shot (wall 203s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.87 ms/shot (wall 203s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=384 sw_p99=384
## shard k=67 seed=200000067 shots=4000 Tue Jun 23 06:09:20 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  57.06 ms/shot (wall 228s)  legs=1.00 sw_exec=275.0  legs_max=4 legs_p99=1  sw_max=1980 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  57.06 ms/shot (wall 228s)  legs=1.00 sw_exec=275.0  legs_max=4 legs_p99=1  sw_max=1980 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  57.06 ms/shot (wall 228s)  legs=1.00 sw_exec=275.0  legs_max=4 legs_p99=1  sw_max=1980 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  57.06 ms/shot (wall 228s)  legs=1.00 sw_exec=275.0  legs_max=4 legs_p99=1  sw_max=1980 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=17.0  57.06 ms/shot (wall 228s)  legs=1.00 sw_exec=275.0  legs_max=4 legs_p99=1  sw_max=1980 sw_p99=500
## shard k=68 seed=200000068 shots=4000 Tue Jun 23 06:13:05 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.33 ms/shot (wall 221s)  legs=1.00 sw_exec=261.1  legs_max=4 legs_p99=1  sw_max=1724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.33 ms/shot (wall 221s)  legs=1.00 sw_exec=261.1  legs_max=4 legs_p99=1  sw_max=1724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.33 ms/shot (wall 221s)  legs=1.00 sw_exec=261.1  legs_max=4 legs_p99=1  sw_max=1724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.33 ms/shot (wall 221s)  legs=1.00 sw_exec=261.1  legs_max=4 legs_p99=1  sw_max=1724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.33 ms/shot (wall 221s)  legs=1.00 sw_exec=261.1  legs_max=4 legs_p99=1  sw_max=1724 sw_p99=500
## shard k=69 seed=200000069 shots=4000 Tue Jun 23 06:16:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.00 ms/shot (wall 204s)  legs=1.00 sw_exec=255.6  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=70 seed=200000070 shots=4000 Tue Jun 23 06:20:00 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.12 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.12 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.12 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.12 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.12 ms/shot (wall 204s)  legs=1.00 sw_exec=255.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=71 seed=200000071 shots=4000 Tue Jun 23 06:23:35 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.93 ms/shot (wall 212s)  legs=1.00 sw_exec=272.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.93 ms/shot (wall 212s)  legs=1.00 sw_exec=272.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.93 ms/shot (wall 212s)  legs=1.00 sw_exec=272.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.93 ms/shot (wall 212s)  legs=1.00 sw_exec=272.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.93 ms/shot (wall 212s)  legs=1.00 sw_exec=272.7  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=72 seed=200000072 shots=4000 Tue Jun 23 06:29:52 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  93.59 ms/shot (wall 374s)  legs=1.01 sw_exec=299.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  93.59 ms/shot (wall 374s)  legs=1.01 sw_exec=299.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  93.59 ms/shot (wall 374s)  legs=1.01 sw_exec=299.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  93.59 ms/shot (wall 374s)  legs=1.01 sw_exec=299.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  93.59 ms/shot (wall 374s)  legs=1.01 sw_exec=299.1  legs_max=24 legs_p99=1  sw_max=12000 sw_p99=500
## shard k=73 seed=200000073 shots=4000 Tue Jun 23 06:34:17 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.22 ms/shot (wall 261s)  legs=1.00 sw_exec=308.4  legs_max=5 legs_p99=1  sw_max=2448 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.22 ms/shot (wall 261s)  legs=1.00 sw_exec=308.4  legs_max=5 legs_p99=1  sw_max=2448 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.22 ms/shot (wall 261s)  legs=1.00 sw_exec=308.4  legs_max=5 legs_p99=1  sw_max=2448 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.22 ms/shot (wall 261s)  legs=1.00 sw_exec=308.4  legs_max=5 legs_p99=1  sw_max=2448 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  65.22 ms/shot (wall 261s)  legs=1.00 sw_exec=308.4  legs_max=5 legs_p99=1  sw_max=2448 sw_p99=500
## shard k=74 seed=200000074 shots=4000 Tue Jun 23 06:37:50 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.35 ms/shot (wall 209s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.35 ms/shot (wall 209s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.35 ms/shot (wall 209s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.35 ms/shot (wall 209s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.35 ms/shot (wall 209s)  legs=1.00 sw_exec=264.8  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=75 seed=200000075 shots=4000 Tue Jun 23 06:41:19 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.55 ms/shot (wall 206s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.55 ms/shot (wall 206s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.55 ms/shot (wall 206s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.55 ms/shot (wall 206s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  51.55 ms/shot (wall 206s)  legs=1.00 sw_exec=254.0  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=76 seed=200000076 shots=4000 Tue Jun 23 06:44:45 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.73 ms/shot (wall 203s)  legs=1.00 sw_exec=242.2  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=77 seed=200000077 shots=4000 Tue Jun 23 06:48:12 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.68 ms/shot (wall 203s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.68 ms/shot (wall 203s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.68 ms/shot (wall 203s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.68 ms/shot (wall 203s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.68 ms/shot (wall 203s)  legs=1.00 sw_exec=239.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=78 seed=200000078 shots=4000 Tue Jun 23 06:51:38 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.84 ms/shot (wall 203s)  legs=1.00 sw_exec=247.3  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=79 seed=200000079 shots=4000 Tue Jun 23 06:55:07 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=261.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=261.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=261.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=261.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.32 ms/shot (wall 205s)  legs=1.00 sw_exec=261.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=80 seed=200000080 shots=4000 Tue Jun 23 06:58:34 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.89 ms/shot (wall 204s)  legs=1.00 sw_exec=245.7  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=81 seed=200000081 shots=4000 Tue Jun 23 07:02:10 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.11 ms/shot (wall 212s)  legs=1.00 sw_exec=279.0  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.11 ms/shot (wall 212s)  legs=1.00 sw_exec=279.0  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.11 ms/shot (wall 212s)  legs=1.00 sw_exec=279.0  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.11 ms/shot (wall 212s)  legs=1.00 sw_exec=279.0  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  53.11 ms/shot (wall 212s)  legs=1.00 sw_exec=279.0  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=82 seed=200000082 shots=4000 Tue Jun 23 07:05:33 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.14 ms/shot (wall 201s)  legs=1.00 sw_exec=231.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.14 ms/shot (wall 201s)  legs=1.00 sw_exec=231.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.14 ms/shot (wall 201s)  legs=1.00 sw_exec=231.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.14 ms/shot (wall 201s)  legs=1.00 sw_exec=231.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.14 ms/shot (wall 201s)  legs=1.00 sw_exec=231.5  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=83 seed=200000083 shots=4000 Tue Jun 23 07:09:55 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  64.46 ms/shot (wall 258s)  legs=1.00 sw_exec=293.3  legs_max=8 legs_p99=1  sw_max=3884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  64.46 ms/shot (wall 258s)  legs=1.00 sw_exec=293.3  legs_max=8 legs_p99=1  sw_max=3884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  64.46 ms/shot (wall 258s)  legs=1.00 sw_exec=293.3  legs_max=8 legs_p99=1  sw_max=3884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  64.46 ms/shot (wall 258s)  legs=1.00 sw_exec=293.3  legs_max=8 legs_p99=1  sw_max=3884 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  64.46 ms/shot (wall 258s)  legs=1.00 sw_exec=293.3  legs_max=8 legs_p99=1  sw_max=3884 sw_p99=500
## shard k=84 seed=200000084 shots=4000 Tue Jun 23 07:13:23 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.26 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.26 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.26 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.26 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  51.26 ms/shot (wall 205s)  legs=1.00 sw_exec=259.2  legs_max=1 legs_p99=1  sw_max=320 sw_p99=320
## shard k=85 seed=200000085 shots=4000 Tue Jun 23 07:17:59 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  68.23 ms/shot (wall 273s)  legs=1.00 sw_exec=266.5  legs_max=12 legs_p99=1  sw_max=5916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  68.23 ms/shot (wall 273s)  legs=1.00 sw_exec=266.5  legs_max=12 legs_p99=1  sw_max=5916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  68.23 ms/shot (wall 273s)  legs=1.00 sw_exec=266.5  legs_max=12 legs_p99=1  sw_max=5916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  68.23 ms/shot (wall 273s)  legs=1.00 sw_exec=266.5  legs_max=12 legs_p99=1  sw_max=5916 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  68.23 ms/shot (wall 273s)  legs=1.00 sw_exec=266.5  legs_max=12 legs_p99=1  sw_max=5916 sw_p99=500
## shard k=86 seed=200000086 shots=4000 Tue Jun 23 07:21:30 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.91 ms/shot (wall 208s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.91 ms/shot (wall 208s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.91 ms/shot (wall 208s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.91 ms/shot (wall 208s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  51.91 ms/shot (wall 208s)  legs=1.00 sw_exec=256.9  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=87 seed=200000087 shots=4000 Tue Jun 23 07:25:13 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.95 ms/shot (wall 220s)  legs=1.00 sw_exec=278.4  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.95 ms/shot (wall 220s)  legs=1.00 sw_exec=278.4  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.95 ms/shot (wall 220s)  legs=1.00 sw_exec=278.4  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.95 ms/shot (wall 220s)  legs=1.00 sw_exec=278.4  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  54.95 ms/shot (wall 220s)  legs=1.00 sw_exec=278.4  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
## shard k=88 seed=200000088 shots=4000 Tue Jun 23 07:29:13 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  58.96 ms/shot (wall 236s)  legs=1.00 sw_exec=285.9  legs_max=5 legs_p99=1  sw_max=2416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  58.96 ms/shot (wall 236s)  legs=1.00 sw_exec=285.9  legs_max=5 legs_p99=1  sw_max=2416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  58.96 ms/shot (wall 236s)  legs=1.00 sw_exec=285.9  legs_max=5 legs_p99=1  sw_max=2416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  58.96 ms/shot (wall 236s)  legs=1.00 sw_exec=285.9  legs_max=5 legs_p99=1  sw_max=2416 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  58.96 ms/shot (wall 236s)  legs=1.00 sw_exec=285.9  legs_max=5 legs_p99=1  sw_max=2416 sw_p99=500
## shard k=89 seed=200000089 shots=4000 Tue Jun 23 07:33:01 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.28 ms/shot (wall 225s)  legs=1.00 sw_exec=275.8  legs_max=4 legs_p99=1  sw_max=1756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.28 ms/shot (wall 225s)  legs=1.00 sw_exec=275.8  legs_max=4 legs_p99=1  sw_max=1756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.28 ms/shot (wall 225s)  legs=1.00 sw_exec=275.8  legs_max=4 legs_p99=1  sw_max=1756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.28 ms/shot (wall 225s)  legs=1.00 sw_exec=275.8  legs_max=4 legs_p99=1  sw_max=1756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.7  56.28 ms/shot (wall 225s)  legs=1.00 sw_exec=275.8  legs_max=4 legs_p99=1  sw_max=1756 sw_p99=500
## shard k=90 seed=200000090 shots=4000 Tue Jun 23 07:37:32 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  66.91 ms/shot (wall 268s)  legs=1.00 sw_exec=280.4  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  66.91 ms/shot (wall 268s)  legs=1.00 sw_exec=280.4  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  66.91 ms/shot (wall 268s)  legs=1.00 sw_exec=280.4  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  66.91 ms/shot (wall 268s)  legs=1.00 sw_exec=280.4  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  66.91 ms/shot (wall 268s)  legs=1.00 sw_exec=280.4  legs_max=8 legs_p99=1  sw_max=3756 sw_p99=500
## shard k=91 seed=200000091 shots=4000 Tue Jun 23 07:40:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.36 ms/shot (wall 201s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.36 ms/shot (wall 201s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.36 ms/shot (wall 201s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.36 ms/shot (wall 201s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  50.36 ms/shot (wall 201s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=92 seed=200000092 shots=4000 Tue Jun 23 07:44:41 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.24 ms/shot (wall 221s)  legs=1.00 sw_exec=283.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.24 ms/shot (wall 221s)  legs=1.00 sw_exec=283.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.24 ms/shot (wall 221s)  legs=1.00 sw_exec=283.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.24 ms/shot (wall 221s)  legs=1.00 sw_exec=283.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  55.24 ms/shot (wall 221s)  legs=1.00 sw_exec=283.6  legs_max=3 legs_p99=1  sw_max=1192 sw_p99=500
## shard k=93 seed=200000093 shots=4000 Tue Jun 23 07:48:15 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.55 ms/shot (wall 210s)  legs=1.00 sw_exec=266.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.55 ms/shot (wall 210s)  legs=1.00 sw_exec=266.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.55 ms/shot (wall 210s)  legs=1.00 sw_exec=266.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.55 ms/shot (wall 210s)  legs=1.00 sw_exec=266.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  52.55 ms/shot (wall 210s)  legs=1.00 sw_exec=266.4  legs_max=2 legs_p99=1  sw_max=724 sw_p99=500
## shard k=94 seed=200000094 shots=4000 Tue Jun 23 07:51:40 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.51 ms/shot (wall 202s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.51 ms/shot (wall 202s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.51 ms/shot (wall 202s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.51 ms/shot (wall 202s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  50.51 ms/shot (wall 202s)  legs=1.00 sw_exec=243.4  legs_max=1 legs_p99=1  sw_max=288 sw_p99=288
## shard k=95 seed=200000095 shots=4000 Tue Jun 23 07:55:21 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.31 ms/shot (wall 217s)  legs=1.00 sw_exec=285.5  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.31 ms/shot (wall 217s)  legs=1.00 sw_exec=285.5  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.31 ms/shot (wall 217s)  legs=1.00 sw_exec=285.5  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.31 ms/shot (wall 217s)  legs=1.00 sw_exec=285.5  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  54.31 ms/shot (wall 217s)  legs=1.00 sw_exec=285.5  legs_max=2 legs_p99=1  sw_max=820 sw_p99=500
## shard k=96 seed=200000096 shots=4000 Tue Jun 23 08:00:57 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  83.33 ms/shot (wall 333s)  legs=1.01 sw_exec=261.8  legs_max=22 legs_p99=1  sw_max=10756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  83.33 ms/shot (wall 333s)  legs=1.01 sw_exec=261.8  legs_max=22 legs_p99=1  sw_max=10756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  83.33 ms/shot (wall 333s)  legs=1.01 sw_exec=261.8  legs_max=22 legs_p99=1  sw_max=10756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  83.33 ms/shot (wall 333s)  legs=1.01 sw_exec=261.8  legs_max=22 legs_p99=1  sw_max=10756 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.9  83.33 ms/shot (wall 333s)  legs=1.01 sw_exec=261.8  legs_max=22 legs_p99=1  sw_max=10756 sw_p99=500
## shard k=97 seed=200000097 shots=4000 Tue Jun 23 08:05:01 PM PDT 2026
pbit-cuda rho_scale=0.3 tv=1 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  60.16 ms/shot (wall 241s)  legs=1.00 sw_exec=277.3  legs_max=7 legs_p99=1  sw_max=3256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=2 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  60.16 ms/shot (wall 241s)  legs=1.00 sw_exec=277.3  legs_max=7 legs_p99=1  sw_max=3256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=3 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  60.16 ms/shot (wall 241s)  legs=1.00 sw_exec=277.3  legs_max=7 legs_p99=1  sw_max=3256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=4 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  60.16 ms/shot (wall 241s)  legs=1.00 sw_exec=277.3  legs_max=7 legs_p99=1  sw_max=3256 sw_p99=500
pbit-cuda rho_scale=0.3 tv=5 LER=0.0000+-0.0000 (0/4000)  valid=1.000 invalid=0  meanW=16.8  60.16 ms/shot (wall 241s)  legs=1.00 sw_exec=277.3  legs_max=7 legs_p99=1  sw_max=3256 sw_p99=500
