# worker filtered_g0 start Tue Jun 23 01:50:24 PM PDT 2026 chunk=40000 base=100000000 args: --device cuda --chains 128 --sweeps 750 --max-legs 24 --rho-scales 0.20 --gamma 1.0 --selection min_weight --basis-filter Z --capture-targets 1,2,3,4,5
## shard k=0 seed=100000000 shots=40000 Tue Jun 23 01:57:23 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.33 ms/shot (wall 413s)  legs=1.00 sw_exec=561.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.33 ms/shot (wall 413s)  legs=1.00 sw_exec=561.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.33 ms/shot (wall 413s)  legs=1.00 sw_exec=561.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.33 ms/shot (wall 413s)  legs=1.00 sw_exec=561.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.33 ms/shot (wall 413s)  legs=1.00 sw_exec=561.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=1 seed=100000001 shots=40000 Tue Jun 23 02:04:10 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.07 ms/shot (wall 403s)  legs=1.00 sw_exec=565.7  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.07 ms/shot (wall 403s)  legs=1.00 sw_exec=565.7  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.07 ms/shot (wall 403s)  legs=1.00 sw_exec=565.7  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.07 ms/shot (wall 403s)  legs=1.00 sw_exec=565.7  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.07 ms/shot (wall 403s)  legs=1.00 sw_exec=565.7  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
## shard k=2 seed=100000002 shots=40000 Tue Jun 23 02:10:32 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.44 ms/shot (wall 378s)  legs=1.00 sw_exec=575.9  legs_max=7 legs_p99=1  sw_max=4916 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.44 ms/shot (wall 378s)  legs=1.00 sw_exec=575.9  legs_max=7 legs_p99=1  sw_max=4916 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.44 ms/shot (wall 378s)  legs=1.00 sw_exec=575.9  legs_max=7 legs_p99=1  sw_max=4916 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.44 ms/shot (wall 378s)  legs=1.00 sw_exec=575.9  legs_max=7 legs_p99=1  sw_max=4916 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.44 ms/shot (wall 378s)  legs=1.00 sw_exec=575.9  legs_max=7 legs_p99=1  sw_max=4916 sw_p99=750
## shard k=3 seed=100000003 shots=40000 Tue Jun 23 02:17:46 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.75 ms/shot (wall 430s)  legs=1.00 sw_exec=564.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.75 ms/shot (wall 430s)  legs=1.00 sw_exec=564.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.75 ms/shot (wall 430s)  legs=1.00 sw_exec=564.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.75 ms/shot (wall 430s)  legs=1.00 sw_exec=564.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.75 ms/shot (wall 430s)  legs=1.00 sw_exec=564.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=4 seed=100000004 shots=40000 Tue Jun 23 02:23:52 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.03 ms/shot (wall 361s)  legs=1.00 sw_exec=533.5  legs_max=4 legs_p99=1  sw_max=2826 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.03 ms/shot (wall 361s)  legs=1.00 sw_exec=533.5  legs_max=4 legs_p99=1  sw_max=2826 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.03 ms/shot (wall 361s)  legs=1.00 sw_exec=533.5  legs_max=4 legs_p99=1  sw_max=2826 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.03 ms/shot (wall 361s)  legs=1.00 sw_exec=533.5  legs_max=4 legs_p99=1  sw_max=2826 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.03 ms/shot (wall 361s)  legs=1.00 sw_exec=533.5  legs_max=4 legs_p99=1  sw_max=2826 sw_p99=750
## shard k=5 seed=100000005 shots=40000 Tue Jun 23 02:30:00 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.10 ms/shot (wall 364s)  legs=1.00 sw_exec=521.8  legs_max=6 legs_p99=1  sw_max=4358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.10 ms/shot (wall 364s)  legs=1.00 sw_exec=521.8  legs_max=6 legs_p99=1  sw_max=4358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.10 ms/shot (wall 364s)  legs=1.00 sw_exec=521.8  legs_max=6 legs_p99=1  sw_max=4358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.10 ms/shot (wall 364s)  legs=1.00 sw_exec=521.8  legs_max=6 legs_p99=1  sw_max=4358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.10 ms/shot (wall 364s)  legs=1.00 sw_exec=521.8  legs_max=6 legs_p99=1  sw_max=4358 sw_p99=750
## shard k=6 seed=100000006 shots=40000 Tue Jun 23 02:36:12 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.19 ms/shot (wall 368s)  legs=1.00 sw_exec=541.0  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.19 ms/shot (wall 368s)  legs=1.00 sw_exec=541.0  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.19 ms/shot (wall 368s)  legs=1.00 sw_exec=541.0  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.19 ms/shot (wall 368s)  legs=1.00 sw_exec=541.0  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.19 ms/shot (wall 368s)  legs=1.00 sw_exec=541.0  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
## shard k=7 seed=100000007 shots=40000 Tue Jun 23 02:42:27 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.26 ms/shot (wall 371s)  legs=1.00 sw_exec=525.1  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.26 ms/shot (wall 371s)  legs=1.00 sw_exec=525.1  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.26 ms/shot (wall 371s)  legs=1.00 sw_exec=525.1  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.26 ms/shot (wall 371s)  legs=1.00 sw_exec=525.1  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.26 ms/shot (wall 371s)  legs=1.00 sw_exec=525.1  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
## shard k=8 seed=100000008 shots=40000 Tue Jun 23 02:49:01 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=551.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=551.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=551.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=551.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=551.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=9 seed=100000009 shots=40000 Tue Jun 23 02:54:54 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.73 ms/shot (wall 349s)  legs=1.00 sw_exec=509.6  legs_max=2 legs_p99=1  sw_max=1262 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.73 ms/shot (wall 349s)  legs=1.00 sw_exec=509.6  legs_max=2 legs_p99=1  sw_max=1262 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.73 ms/shot (wall 349s)  legs=1.00 sw_exec=509.6  legs_max=2 legs_p99=1  sw_max=1262 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.73 ms/shot (wall 349s)  legs=1.00 sw_exec=509.6  legs_max=2 legs_p99=1  sw_max=1262 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.73 ms/shot (wall 349s)  legs=1.00 sw_exec=509.6  legs_max=2 legs_p99=1  sw_max=1262 sw_p99=750
## shard k=10 seed=100000010 shots=40000 Tue Jun 23 03:01:05 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.17 ms/shot (wall 367s)  legs=1.00 sw_exec=520.3  legs_max=7 legs_p99=1  sw_max=5108 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.17 ms/shot (wall 367s)  legs=1.00 sw_exec=520.3  legs_max=7 legs_p99=1  sw_max=5108 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.17 ms/shot (wall 367s)  legs=1.00 sw_exec=520.3  legs_max=7 legs_p99=1  sw_max=5108 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.17 ms/shot (wall 367s)  legs=1.00 sw_exec=520.3  legs_max=7 legs_p99=1  sw_max=5108 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.17 ms/shot (wall 367s)  legs=1.00 sw_exec=520.3  legs_max=7 legs_p99=1  sw_max=5108 sw_p99=750
## shard k=11 seed=100000011 shots=40000 Tue Jun 23 03:07:53 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.09 ms/shot (wall 404s)  legs=1.00 sw_exec=554.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.09 ms/shot (wall 404s)  legs=1.00 sw_exec=554.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.09 ms/shot (wall 404s)  legs=1.00 sw_exec=554.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.09 ms/shot (wall 404s)  legs=1.00 sw_exec=554.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.09 ms/shot (wall 404s)  legs=1.00 sw_exec=554.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=12 seed=100000012 shots=40000 Tue Jun 23 03:13:44 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.68 ms/shot (wall 347s)  legs=1.00 sw_exec=496.7  legs_max=1 legs_p99=1  sw_max=608 sw_p99=608
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.68 ms/shot (wall 347s)  legs=1.00 sw_exec=496.7  legs_max=1 legs_p99=1  sw_max=608 sw_p99=608
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.68 ms/shot (wall 347s)  legs=1.00 sw_exec=496.7  legs_max=1 legs_p99=1  sw_max=608 sw_p99=608
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.68 ms/shot (wall 347s)  legs=1.00 sw_exec=496.7  legs_max=1 legs_p99=1  sw_max=608 sw_p99=608
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.68 ms/shot (wall 347s)  legs=1.00 sw_exec=496.7  legs_max=1 legs_p99=1  sw_max=608 sw_p99=608
## shard k=13 seed=100000013 shots=40000 Tue Jun 23 03:20:13 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.61 ms/shot (wall 385s)  legs=1.00 sw_exec=554.8  legs_max=9 legs_p99=1  sw_max=6384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.61 ms/shot (wall 385s)  legs=1.00 sw_exec=554.8  legs_max=9 legs_p99=1  sw_max=6384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.61 ms/shot (wall 385s)  legs=1.00 sw_exec=554.8  legs_max=9 legs_p99=1  sw_max=6384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.61 ms/shot (wall 385s)  legs=1.00 sw_exec=554.8  legs_max=9 legs_p99=1  sw_max=6384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.61 ms/shot (wall 385s)  legs=1.00 sw_exec=554.8  legs_max=9 legs_p99=1  sw_max=6384 sw_p99=750
## shard k=14 seed=100000014 shots=40000 Tue Jun 23 03:26:45 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.69 ms/shot (wall 387s)  legs=1.00 sw_exec=569.7  legs_max=17 legs_p99=1  sw_max=12384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.69 ms/shot (wall 387s)  legs=1.00 sw_exec=569.7  legs_max=17 legs_p99=1  sw_max=12384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.69 ms/shot (wall 387s)  legs=1.00 sw_exec=569.7  legs_max=17 legs_p99=1  sw_max=12384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.69 ms/shot (wall 387s)  legs=1.00 sw_exec=569.7  legs_max=17 legs_p99=1  sw_max=12384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.69 ms/shot (wall 387s)  legs=1.00 sw_exec=569.7  legs_max=17 legs_p99=1  sw_max=12384 sw_p99=750
## shard k=15 seed=100000015 shots=40000 Tue Jun 23 03:34:45 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.91 ms/shot (wall 476s)  legs=1.00 sw_exec=573.9  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.91 ms/shot (wall 476s)  legs=1.00 sw_exec=573.9  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.91 ms/shot (wall 476s)  legs=1.00 sw_exec=573.9  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.91 ms/shot (wall 476s)  legs=1.00 sw_exec=573.9  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.91 ms/shot (wall 476s)  legs=1.00 sw_exec=573.9  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=16 seed=100000016 shots=40000 Tue Jun 23 03:41:33 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.10 ms/shot (wall 404s)  legs=1.00 sw_exec=584.8  legs_max=15 legs_p99=1  sw_max=11076 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.10 ms/shot (wall 404s)  legs=1.00 sw_exec=584.8  legs_max=15 legs_p99=1  sw_max=11076 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.10 ms/shot (wall 404s)  legs=1.00 sw_exec=584.8  legs_max=15 legs_p99=1  sw_max=11076 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.10 ms/shot (wall 404s)  legs=1.00 sw_exec=584.8  legs_max=15 legs_p99=1  sw_max=11076 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.10 ms/shot (wall 404s)  legs=1.00 sw_exec=584.8  legs_max=15 legs_p99=1  sw_max=11076 sw_p99=750
## shard k=17 seed=100000017 shots=40000 Tue Jun 23 03:48:32 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.37 ms/shot (wall 415s)  legs=1.00 sw_exec=580.1  legs_max=17 legs_p99=1  sw_max=12704 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.37 ms/shot (wall 415s)  legs=1.00 sw_exec=580.1  legs_max=17 legs_p99=1  sw_max=12704 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.37 ms/shot (wall 415s)  legs=1.00 sw_exec=580.1  legs_max=17 legs_p99=1  sw_max=12704 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.37 ms/shot (wall 415s)  legs=1.00 sw_exec=580.1  legs_max=17 legs_p99=1  sw_max=12704 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.37 ms/shot (wall 415s)  legs=1.00 sw_exec=580.1  legs_max=17 legs_p99=1  sw_max=12704 sw_p99=750
## shard k=18 seed=100000018 shots=40000 Tue Jun 23 03:55:25 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.20 ms/shot (wall 408s)  legs=1.00 sw_exec=587.0  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.20 ms/shot (wall 408s)  legs=1.00 sw_exec=587.0  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.20 ms/shot (wall 408s)  legs=1.00 sw_exec=587.0  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.20 ms/shot (wall 408s)  legs=1.00 sw_exec=587.0  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.20 ms/shot (wall 408s)  legs=1.00 sw_exec=587.0  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=19 seed=100000019 shots=40000 Tue Jun 23 04:02:30 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.53 ms/shot (wall 421s)  legs=1.00 sw_exec=571.4  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.53 ms/shot (wall 421s)  legs=1.00 sw_exec=571.4  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.53 ms/shot (wall 421s)  legs=1.00 sw_exec=571.4  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.53 ms/shot (wall 421s)  legs=1.00 sw_exec=571.4  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.53 ms/shot (wall 421s)  legs=1.00 sw_exec=571.4  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=20 seed=100000020 shots=40000 Tue Jun 23 04:08:40 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.16 ms/shot (wall 366s)  legs=1.00 sw_exec=523.0  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.16 ms/shot (wall 366s)  legs=1.00 sw_exec=523.0  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.16 ms/shot (wall 366s)  legs=1.00 sw_exec=523.0  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.16 ms/shot (wall 366s)  legs=1.00 sw_exec=523.0  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.16 ms/shot (wall 366s)  legs=1.00 sw_exec=523.0  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
## shard k=21 seed=100000021 shots=40000 Tue Jun 23 04:15:40 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.39 ms/shot (wall 416s)  legs=1.00 sw_exec=549.9  legs_max=24 legs_p99=1  sw_max=17666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.39 ms/shot (wall 416s)  legs=1.00 sw_exec=549.9  legs_max=24 legs_p99=1  sw_max=17666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.39 ms/shot (wall 416s)  legs=1.00 sw_exec=549.9  legs_max=24 legs_p99=1  sw_max=17666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.39 ms/shot (wall 416s)  legs=1.00 sw_exec=549.9  legs_max=24 legs_p99=1  sw_max=17666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.39 ms/shot (wall 416s)  legs=1.00 sw_exec=549.9  legs_max=24 legs_p99=1  sw_max=17666 sw_p99=750
## shard k=22 seed=100000022 shots=40000 Tue Jun 23 04:22:27 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.06 ms/shot (wall 402s)  legs=1.00 sw_exec=562.6  legs_max=21 legs_p99=1  sw_max=15384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.06 ms/shot (wall 402s)  legs=1.00 sw_exec=562.6  legs_max=21 legs_p99=1  sw_max=15384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.06 ms/shot (wall 402s)  legs=1.00 sw_exec=562.6  legs_max=21 legs_p99=1  sw_max=15384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.06 ms/shot (wall 402s)  legs=1.00 sw_exec=562.6  legs_max=21 legs_p99=1  sw_max=15384 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.06 ms/shot (wall 402s)  legs=1.00 sw_exec=562.6  legs_max=21 legs_p99=1  sw_max=15384 sw_p99=750
## shard k=23 seed=100000023 shots=40000 Tue Jun 23 04:29:13 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.05 ms/shot (wall 402s)  legs=1.00 sw_exec=587.5  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.05 ms/shot (wall 402s)  legs=1.00 sw_exec=587.5  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.05 ms/shot (wall 402s)  legs=1.00 sw_exec=587.5  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.05 ms/shot (wall 402s)  legs=1.00 sw_exec=587.5  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.05 ms/shot (wall 402s)  legs=1.00 sw_exec=587.5  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
## shard k=24 seed=100000024 shots=40000 Tue Jun 23 04:35:55 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.93 ms/shot (wall 397s)  legs=1.00 sw_exec=562.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.93 ms/shot (wall 397s)  legs=1.00 sw_exec=562.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.93 ms/shot (wall 397s)  legs=1.00 sw_exec=562.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.93 ms/shot (wall 397s)  legs=1.00 sw_exec=562.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.93 ms/shot (wall 397s)  legs=1.00 sw_exec=562.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=25 seed=100000025 shots=40000 Tue Jun 23 04:43:20 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=611.5  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=611.5  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=611.5  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=611.5  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=611.5  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
## shard k=26 seed=100000026 shots=40000 Tue Jun 23 04:50:25 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.52 ms/shot (wall 421s)  legs=1.00 sw_exec=584.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.52 ms/shot (wall 421s)  legs=1.00 sw_exec=584.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.52 ms/shot (wall 421s)  legs=1.00 sw_exec=584.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.52 ms/shot (wall 421s)  legs=1.00 sw_exec=584.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=1  LER_strict=0.0000 (1/40000)  meanW=11.8  10.52 ms/shot (wall 421s)  legs=1.00 sw_exec=584.1  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=27 seed=100000027 shots=40000 Tue Jun 23 04:57:04 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.86 ms/shot (wall 395s)  legs=1.00 sw_exec=573.0  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.86 ms/shot (wall 395s)  legs=1.00 sw_exec=573.0  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.86 ms/shot (wall 395s)  legs=1.00 sw_exec=573.0  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.86 ms/shot (wall 395s)  legs=1.00 sw_exec=573.0  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.86 ms/shot (wall 395s)  legs=1.00 sw_exec=573.0  legs_max=12 legs_p99=1  sw_max=8730 sw_p99=750
## shard k=28 seed=100000028 shots=40000 Tue Jun 23 05:03:32 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.59 ms/shot (wall 384s)  legs=1.00 sw_exec=548.8  legs_max=8 legs_p99=1  sw_max=5666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.59 ms/shot (wall 384s)  legs=1.00 sw_exec=548.8  legs_max=8 legs_p99=1  sw_max=5666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.59 ms/shot (wall 384s)  legs=1.00 sw_exec=548.8  legs_max=8 legs_p99=1  sw_max=5666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.59 ms/shot (wall 384s)  legs=1.00 sw_exec=548.8  legs_max=8 legs_p99=1  sw_max=5666 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.59 ms/shot (wall 384s)  legs=1.00 sw_exec=548.8  legs_max=8 legs_p99=1  sw_max=5666 sw_p99=750
## shard k=29 seed=100000029 shots=40000 Tue Jun 23 05:10:55 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.98 ms/shot (wall 439s)  legs=1.00 sw_exec=587.9  legs_max=20 legs_p99=1  sw_max=14794 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.98 ms/shot (wall 439s)  legs=1.00 sw_exec=587.9  legs_max=20 legs_p99=1  sw_max=14794 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.98 ms/shot (wall 439s)  legs=1.00 sw_exec=587.9  legs_max=20 legs_p99=1  sw_max=14794 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.98 ms/shot (wall 439s)  legs=1.00 sw_exec=587.9  legs_max=20 legs_p99=1  sw_max=14794 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.98 ms/shot (wall 439s)  legs=1.00 sw_exec=587.9  legs_max=20 legs_p99=1  sw_max=14794 sw_p99=750
## shard k=30 seed=100000030 shots=40000 Tue Jun 23 05:17:43 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.08 ms/shot (wall 403s)  legs=1.00 sw_exec=555.0  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.08 ms/shot (wall 403s)  legs=1.00 sw_exec=555.0  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.08 ms/shot (wall 403s)  legs=1.00 sw_exec=555.0  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.08 ms/shot (wall 403s)  legs=1.00 sw_exec=555.0  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.08 ms/shot (wall 403s)  legs=1.00 sw_exec=555.0  legs_max=21 legs_p99=1  sw_max=15448 sw_p99=750
## shard k=31 seed=100000031 shots=40000 Tue Jun 23 05:24:41 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=0  meanW=11.8  10.35 ms/shot (wall 414s)  legs=1.00 sw_exec=588.0  legs_max=21 legs_p99=1  sw_max=15608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (1/40000)  valid=1.000 invalid=0  meanW=11.8  10.35 ms/shot (wall 414s)  legs=1.00 sw_exec=588.0  legs_max=21 legs_p99=1  sw_max=15608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.35 ms/shot (wall 414s)  legs=1.00 sw_exec=588.0  legs_max=21 legs_p99=1  sw_max=15608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.35 ms/shot (wall 414s)  legs=1.00 sw_exec=588.0  legs_max=21 legs_p99=1  sw_max=15608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.35 ms/shot (wall 414s)  legs=1.00 sw_exec=588.0  legs_max=21 legs_p99=1  sw_max=15608 sw_p99=750
## shard k=32 seed=100000032 shots=40000 Tue Jun 23 05:31:14 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.72 ms/shot (wall 389s)  legs=1.00 sw_exec=559.4  legs_max=8 legs_p99=1  sw_max=5858 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.72 ms/shot (wall 389s)  legs=1.00 sw_exec=559.4  legs_max=8 legs_p99=1  sw_max=5858 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.72 ms/shot (wall 389s)  legs=1.00 sw_exec=559.4  legs_max=8 legs_p99=1  sw_max=5858 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.72 ms/shot (wall 389s)  legs=1.00 sw_exec=559.4  legs_max=8 legs_p99=1  sw_max=5858 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.72 ms/shot (wall 389s)  legs=1.00 sw_exec=559.4  legs_max=8 legs_p99=1  sw_max=5858 sw_p99=750
## shard k=33 seed=100000033 shots=40000 Tue Jun 23 05:38:13 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.36 ms/shot (wall 414s)  legs=1.00 sw_exec=578.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.36 ms/shot (wall 414s)  legs=1.00 sw_exec=578.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.36 ms/shot (wall 414s)  legs=1.00 sw_exec=578.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.36 ms/shot (wall 414s)  legs=1.00 sw_exec=578.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.36 ms/shot (wall 414s)  legs=1.00 sw_exec=578.7  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=34 seed=100000034 shots=40000 Tue Jun 23 05:45:08 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.28 ms/shot (wall 411s)  legs=1.00 sw_exec=566.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.28 ms/shot (wall 411s)  legs=1.00 sw_exec=566.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.28 ms/shot (wall 411s)  legs=1.00 sw_exec=566.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.28 ms/shot (wall 411s)  legs=1.00 sw_exec=566.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.28 ms/shot (wall 411s)  legs=1.00 sw_exec=566.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=35 seed=100000035 shots=40000 Tue Jun 23 05:52:04 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.30 ms/shot (wall 412s)  legs=1.00 sw_exec=552.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.30 ms/shot (wall 412s)  legs=1.00 sw_exec=552.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.30 ms/shot (wall 412s)  legs=1.00 sw_exec=552.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.30 ms/shot (wall 412s)  legs=1.00 sw_exec=552.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.30 ms/shot (wall 412s)  legs=1.00 sw_exec=552.5  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=36 seed=100000036 shots=40000 Tue Jun 23 05:58:34 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.63 ms/shot (wall 385s)  legs=1.00 sw_exec=586.9  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.63 ms/shot (wall 385s)  legs=1.00 sw_exec=586.9  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.63 ms/shot (wall 385s)  legs=1.00 sw_exec=586.9  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.63 ms/shot (wall 385s)  legs=1.00 sw_exec=586.9  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.63 ms/shot (wall 385s)  legs=1.00 sw_exec=586.9  legs_max=8 legs_p99=1  sw_max=5762 sw_p99=750
## shard k=37 seed=100000037 shots=40000 Tue Jun 23 06:05:23 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.12 ms/shot (wall 405s)  legs=1.00 sw_exec=520.6  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.12 ms/shot (wall 405s)  legs=1.00 sw_exec=520.6  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.12 ms/shot (wall 405s)  legs=1.00 sw_exec=520.6  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.12 ms/shot (wall 405s)  legs=1.00 sw_exec=520.6  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.12 ms/shot (wall 405s)  legs=1.00 sw_exec=520.6  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=38 seed=100000038 shots=40000 Tue Jun 23 06:12:44 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.93 ms/shot (wall 437s)  legs=1.00 sw_exec=607.6  legs_max=22 legs_p99=1  sw_max=16358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.93 ms/shot (wall 437s)  legs=1.00 sw_exec=607.6  legs_max=22 legs_p99=1  sw_max=16358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.93 ms/shot (wall 437s)  legs=1.00 sw_exec=607.6  legs_max=22 legs_p99=1  sw_max=16358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.93 ms/shot (wall 437s)  legs=1.00 sw_exec=607.6  legs_max=22 legs_p99=1  sw_max=16358 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.93 ms/shot (wall 437s)  legs=1.00 sw_exec=607.6  legs_max=22 legs_p99=1  sw_max=16358 sw_p99=750
## shard k=39 seed=100000039 shots=40000 Tue Jun 23 06:19:18 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=538.9  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=538.9  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=538.9  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=538.9  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.75 ms/shot (wall 390s)  legs=1.00 sw_exec=538.9  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
## shard k=40 seed=100000040 shots=40000 Tue Jun 23 06:26:28 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.64 ms/shot (wall 425s)  legs=1.00 sw_exec=572.0  legs_max=22 legs_p99=1  sw_max=16390 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.64 ms/shot (wall 425s)  legs=1.00 sw_exec=572.0  legs_max=22 legs_p99=1  sw_max=16390 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.64 ms/shot (wall 425s)  legs=1.00 sw_exec=572.0  legs_max=22 legs_p99=1  sw_max=16390 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.64 ms/shot (wall 425s)  legs=1.00 sw_exec=572.0  legs_max=22 legs_p99=1  sw_max=16390 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.64 ms/shot (wall 425s)  legs=1.00 sw_exec=572.0  legs_max=22 legs_p99=1  sw_max=16390 sw_p99=750
## shard k=41 seed=100000041 shots=40000 Tue Jun 23 06:32:59 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=543.4  legs_max=15 legs_p99=1  sw_max=11044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=543.4  legs_max=15 legs_p99=1  sw_max=11044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=543.4  legs_max=15 legs_p99=1  sw_max=11044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=543.4  legs_max=15 legs_p99=1  sw_max=11044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=543.4  legs_max=15 legs_p99=1  sw_max=11044 sw_p99=750
## shard k=42 seed=100000042 shots=40000 Tue Jun 23 06:39:14 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.28 ms/shot (wall 371s)  legs=1.00 sw_exec=566.2  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.28 ms/shot (wall 371s)  legs=1.00 sw_exec=566.2  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.28 ms/shot (wall 371s)  legs=1.00 sw_exec=566.2  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.28 ms/shot (wall 371s)  legs=1.00 sw_exec=566.2  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.28 ms/shot (wall 371s)  legs=1.00 sw_exec=566.2  legs_max=9 legs_p99=1  sw_max=6480 sw_p99=750
## shard k=43 seed=100000043 shots=40000 Tue Jun 23 06:45:32 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.34 ms/shot (wall 374s)  legs=1.00 sw_exec=529.7  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.34 ms/shot (wall 374s)  legs=1.00 sw_exec=529.7  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.34 ms/shot (wall 374s)  legs=1.00 sw_exec=529.7  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.34 ms/shot (wall 374s)  legs=1.00 sw_exec=529.7  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.34 ms/shot (wall 374s)  legs=1.00 sw_exec=529.7  legs_max=13 legs_p99=1  sw_max=9416 sw_p99=750
## shard k=44 seed=100000044 shots=40000 Tue Jun 23 06:52:09 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.80 ms/shot (wall 392s)  legs=1.00 sw_exec=582.3  legs_max=11 legs_p99=1  sw_max=7948 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.80 ms/shot (wall 392s)  legs=1.00 sw_exec=582.3  legs_max=11 legs_p99=1  sw_max=7948 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.80 ms/shot (wall 392s)  legs=1.00 sw_exec=582.3  legs_max=11 legs_p99=1  sw_max=7948 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.80 ms/shot (wall 392s)  legs=1.00 sw_exec=582.3  legs_max=11 legs_p99=1  sw_max=7948 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.80 ms/shot (wall 392s)  legs=1.00 sw_exec=582.3  legs_max=11 legs_p99=1  sw_max=7948 sw_p99=750
## shard k=45 seed=100000045 shots=40000 Tue Jun 23 06:59:02 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=548.2  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=548.2  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=548.2  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=548.2  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=548.2  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=46 seed=100000046 shots=40000 Tue Jun 23 07:06:28 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=596.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=596.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=596.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=596.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  11.03 ms/shot (wall 441s)  legs=1.00 sw_exec=596.3  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=47 seed=100000047 shots=40000 Tue Jun 23 07:12:58 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=557.7  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=557.7  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=557.7  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=557.7  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.65 ms/shot (wall 386s)  legs=1.00 sw_exec=557.7  legs_max=9 legs_p99=1  sw_max=6512 sw_p99=750
## shard k=48 seed=100000048 shots=40000 Tue Jun 23 07:19:38 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.89 ms/shot (wall 396s)  legs=1.00 sw_exec=557.5  legs_max=18 legs_p99=1  sw_max=13294 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.89 ms/shot (wall 396s)  legs=1.00 sw_exec=557.5  legs_max=18 legs_p99=1  sw_max=13294 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.89 ms/shot (wall 396s)  legs=1.00 sw_exec=557.5  legs_max=18 legs_p99=1  sw_max=13294 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.89 ms/shot (wall 396s)  legs=1.00 sw_exec=557.5  legs_max=18 legs_p99=1  sw_max=13294 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.89 ms/shot (wall 396s)  legs=1.00 sw_exec=557.5  legs_max=18 legs_p99=1  sw_max=13294 sw_p99=750
## shard k=49 seed=100000049 shots=40000 Tue Jun 23 07:25:43 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.01 ms/shot (wall 360s)  legs=1.00 sw_exec=516.7  legs_max=7 legs_p99=1  sw_max=5044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.01 ms/shot (wall 360s)  legs=1.00 sw_exec=516.7  legs_max=7 legs_p99=1  sw_max=5044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.01 ms/shot (wall 360s)  legs=1.00 sw_exec=516.7  legs_max=7 legs_p99=1  sw_max=5044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.01 ms/shot (wall 360s)  legs=1.00 sw_exec=516.7  legs_max=7 legs_p99=1  sw_max=5044 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.01 ms/shot (wall 360s)  legs=1.00 sw_exec=516.7  legs_max=7 legs_p99=1  sw_max=5044 sw_p99=750
## shard k=50 seed=100000050 shots=40000 Tue Jun 23 07:32:27 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.00 ms/shot (wall 400s)  legs=1.00 sw_exec=584.7  legs_max=17 legs_p99=1  sw_max=12608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.00 ms/shot (wall 400s)  legs=1.00 sw_exec=584.7  legs_max=17 legs_p99=1  sw_max=12608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.00 ms/shot (wall 400s)  legs=1.00 sw_exec=584.7  legs_max=17 legs_p99=1  sw_max=12608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.00 ms/shot (wall 400s)  legs=1.00 sw_exec=584.7  legs_max=17 legs_p99=1  sw_max=12608 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.00 ms/shot (wall 400s)  legs=1.00 sw_exec=584.7  legs_max=17 legs_p99=1  sw_max=12608 sw_p99=750
## shard k=51 seed=100000051 shots=40000 Tue Jun 23 07:38:19 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.70 ms/shot (wall 348s)  legs=1.00 sw_exec=499.8  legs_max=1 legs_p99=1  sw_max=576 sw_p99=576
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.70 ms/shot (wall 348s)  legs=1.00 sw_exec=499.8  legs_max=1 legs_p99=1  sw_max=576 sw_p99=576
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.70 ms/shot (wall 348s)  legs=1.00 sw_exec=499.8  legs_max=1 legs_p99=1  sw_max=576 sw_p99=576
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.70 ms/shot (wall 348s)  legs=1.00 sw_exec=499.8  legs_max=1 legs_p99=1  sw_max=576 sw_p99=576
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  8.70 ms/shot (wall 348s)  legs=1.00 sw_exec=499.8  legs_max=1 legs_p99=1  sw_max=576 sw_p99=576
## shard k=52 seed=100000052 shots=40000 Tue Jun 23 07:45:13 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=580.0  legs_max=16 legs_p99=1  sw_max=11762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=580.0  legs_max=16 legs_p99=1  sw_max=11762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=580.0  legs_max=16 legs_p99=1  sw_max=11762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=580.0  legs_max=16 legs_p99=1  sw_max=11762 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.23 ms/shot (wall 409s)  legs=1.00 sw_exec=580.0  legs_max=16 legs_p99=1  sw_max=11762 sw_p99=750
## shard k=53 seed=100000053 shots=40000 Tue Jun 23 07:52:23 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.65 ms/shot (wall 426s)  legs=1.00 sw_exec=568.8  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.65 ms/shot (wall 426s)  legs=1.00 sw_exec=568.8  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.65 ms/shot (wall 426s)  legs=1.00 sw_exec=568.8  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.65 ms/shot (wall 426s)  legs=1.00 sw_exec=568.8  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  10.65 ms/shot (wall 426s)  legs=1.00 sw_exec=568.8  legs_max=24 legs_p99=1  sw_max=18000 sw_p99=750
## shard k=54 seed=100000054 shots=40000 Tue Jun 23 07:58:42 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.38 ms/shot (wall 375s)  legs=1.00 sw_exec=580.6  legs_max=8 legs_p99=1  sw_max=5730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.38 ms/shot (wall 375s)  legs=1.00 sw_exec=580.6  legs_max=8 legs_p99=1  sw_max=5730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.38 ms/shot (wall 375s)  legs=1.00 sw_exec=580.6  legs_max=8 legs_p99=1  sw_max=5730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.38 ms/shot (wall 375s)  legs=1.00 sw_exec=580.6  legs_max=8 legs_p99=1  sw_max=5730 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.38 ms/shot (wall 375s)  legs=1.00 sw_exec=580.6  legs_max=8 legs_p99=1  sw_max=5730 sw_p99=750
## shard k=55 seed=100000055 shots=40000 Tue Jun 23 08:05:03 PM PDT 2026
pbit-cuda rho_scale=0.2 tv=1 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.41 ms/shot (wall 377s)  legs=1.00 sw_exec=584.3  legs_max=6 legs_p99=1  sw_max=4166 sw_p99=750
pbit-cuda rho_scale=0.2 tv=2 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.41 ms/shot (wall 377s)  legs=1.00 sw_exec=584.3  legs_max=6 legs_p99=1  sw_max=4166 sw_p99=750
pbit-cuda rho_scale=0.2 tv=3 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.41 ms/shot (wall 377s)  legs=1.00 sw_exec=584.3  legs_max=6 legs_p99=1  sw_max=4166 sw_p99=750
pbit-cuda rho_scale=0.2 tv=4 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.41 ms/shot (wall 377s)  legs=1.00 sw_exec=584.3  legs_max=6 legs_p99=1  sw_max=4166 sw_p99=750
pbit-cuda rho_scale=0.2 tv=5 LER=0.0000+-0.0000 (0/40000)  valid=1.000 invalid=0  meanW=11.8  9.41 ms/shot (wall 377s)  legs=1.00 sw_exec=584.3  legs_max=6 legs_p99=1  sw_max=4166 sw_p99=750
