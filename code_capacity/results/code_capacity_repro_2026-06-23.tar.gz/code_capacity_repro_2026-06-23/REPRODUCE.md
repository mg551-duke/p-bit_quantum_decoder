# Code-Capacity Decoder Results -- Reproducibility Bundle

Self-contained snapshot of the code used to produce the B1 code-capacity
(bit-flip / X-error) LER-vs-p results with the p-bit ColoredBlockGibbs decoder,
plus the result artifacts. Generated 2026-06-23.

## Layout
- src/pbit_qec/                          Decoder core (exact import closure, 9 modules).
- code_capacity/run_code_capacity.py     THE simulation harness (CPU pool + CUDA engine).
- code_capacity/run_b1_psweep.sh         Ladder driver (L1..L4 x p sweep).
- code_capacity/run_lowp_pool.py         Multi-GPU pooled low-p top-up controller.
- code_capacity/psweep_report.py         Report / table generator.
- code_capacity/tune_code_capacity.py    Operating-point tuning harness.
- code_capacity/codes/                   B1/B2 CSS codes (Hx,Hz,Lx,Lz .npz).
- code_capacity/results/b1_psweep/       Main LER-vs-p sweep artifacts.
- code_capacity/results/b1_lowp/         L3 low-p (p=0.04,0.05) pooled top-up.
- code_capacity/results/b1_sw1500_p06/   Deep p=0.06 campaign.
- pyproject.toml, uv.lock                Pinned environment.

## Environment
Python 3.12. Core deps: numpy, scipy, pandas. The GPU path needs an NVIDIA GPU +
CuPy (cupy-cuda12x). Install with uv (`uv sync`) or pip
(`pip install numpy scipy pandas cupy-cuda12x`). No install of this package is
required: the scripts prepend src/ to sys.path; you may also run with PYTHONPATH=src.

## Reproduce
Single point (GPU), best "L4" decoder at p=0.06:
    PYTHONPATH=src python code_capacity/run_code_capacity.py \
        --codes code_capacity/codes/B1_HxHzLxLz.npz --p 0.06 \
        --device cuda --chains 256 --sweeps 3000 --max-legs 24 --target-valid 8 \
        --rho-scale 0.35 --beta-start 0.5 --beta-stop 5.0 --shape linear \
        --target-errors 40 --output-dir /tmp/b1_p06_test

Full L1..L4 x p ladder sweep (multi-GPU; GPU pool set inside the script):
    bash code_capacity/run_b1_psweep.sh

Low-p pooled top-up to >=10 true-logical errors (e.g. L3 on GPUs 3-5):
    python code_capacity/run_lowp_pool.py --p 0.05 0.04 --gpus 3 4 5 --target-errors 10

Render the LER-vs-p table from a results dir:
    PYTHONPATH=src python code_capacity/psweep_report.py

GPU selection is via CUDA_VISIBLE_DEVICES (the drivers pin one device per shard).

## Decoder ladder (cheap -> expensive)
    L1: sweeps=300,  max_legs=1,  target_valid=1
    L2: sweeps=800,  max_legs=4,  target_valid=4
    L3: sweeps=1500, max_legs=10, target_valid=8
    L4: sweeps=3000, max_legs=24, target_valid=8   <- best / most expensive
  Shared: chains=256, rho_scale=0.35, beta 0.5->5.0 linear, update=gibbs,
  selection=min_weight, coloring=on, device=cuda.

## LER definitions (2x2 grid: {valid,invalid} x {correct,incorrect})
    content LER (true logical) = valid_incorrect + invalid_incorrect, per run.
    legacy  LER (strict)       = valid_incorrect + all-nonconvergent,  per run.

## Headline results -- B1, deepest step L4, content LER (true logical)
    p=0.04: <5e-5 (0/60k)      p=0.08: 4.18e-2 (209/5k)
    p=0.05: <5e-5 (0/60k)      p=0.09: 2.25e-1 (1124/5k)
    p=0.06: 1.17e-4 (7/60k)    p=0.10: 6.03e-1 (3014/5k)
    p=0.07: 2.65e-3 (53/20k)
  Low-p true-logical points (p=0.04/0.05) are being extended with
  run_lowp_pool.py; see code_capacity/results/b1_lowp/.
